import json
import pandas as pd
import random
from pathlib import Path
from typing import Union
import math

def main():
    df = make_df_from_schema("labels.json")
    for i in range(10000):
        #車両番号
        vehicleNo = random.randint(1,1000)
        # ランダムな日時（過去1年以内）を生成して同フォーマットの文字列にする
        now = pd.Timestamp.now()
        start = now - pd.Timedelta(days=365)
        rand_seconds = random.uniform(0, (now - start).total_seconds())
        rand_dt = start + pd.Timedelta(seconds=rand_seconds)
        date_str = rand_dt.strftime("%Y-%m-%d %H:%M:%S")
        ChargeTime = random.randint(30,60)
        ChargeCnt = random.randint(1,4)
        
        df = make_df_1record(df,vehicleNo,date_str,ChargeTime=ChargeTime,ChargeCnt=ChargeCnt,ACDCFLG=random.choice([0,1]))
        df = make_df_record_CAN(df,vehicleNo,date_str,ChargeTime)
        print(i)
    
    # CSVエクスポート
    out_path = Path("labels_export.csv")
    if df is None or df.empty:
        print("DataFrame is empty, skipping CSV export.")
    else:
        df.to_csv(out_path, index=False, encoding="utf-8-sig")
        print(f"Exported DataFrame to: {out_path.resolve()}")

# schema.json から DataFrame を作成
def make_df_from_schema(json_path: Union[str, Path]) -> pd.DataFrame:
    data = json.loads(Path(json_path).read_text(encoding="utf-8"))
    cols = data["columns"]

    if not cols:
        return pd.DataFrame()

    # 文字列リスト形式にも対応
    if isinstance(cols[0], str):
        return pd.DataFrame(columns=cols)

    names = [c["name"] for c in cols]
    dtypes = {c["name"]: c["dtype"] for c in cols if "dtype" in c}

    df = pd.DataFrame(columns=names)

    # データ型を設定
    for k, v in dtypes.items():
        if v.startswith("datetime"):
            continue
        df[k] = df[k].astype(v)

    return df

# DataFrame に1レコード追加
def make_df_1record(df: pd.DataFrame, vehicleNo: int, date_str: str, ChargeTime: int, ChargeCnt: int, ACDCFLG: int) -> pd.DataFrame:
    if df is None:
        return df
    
    row = {}
    for col in df.columns:
        
        # 車両番号
        if col in ("VEHICLE_NO"):
            #row[col] = random.randint(1, 20)
            row[col] = vehicleNo
            continue
        
        # 日付
        if col in ("DATE"):
            row[col] = date_str
            continue
        
        # EVSEのMACアドレス
        if col in ("EVSE_MACADDRESS_1", "EVSE_MACADDRESS_2", "EVSE_MACADDRESS_3", "EVSE_MACADDRESS_4"):
            # ランダムなMACアドレスを生成してStringDtypeで格納
            for i in range(ChargeCnt):
                if col == f"EVSE_MACADDRESS_{i+1}":
                    mac = ":".join(f"{random.randint(0,255):02X}" for _ in range(6))
                    i = pd.Series(mac, dtype="string").iat[0]
                    row[col] = i
                    break
            continue
        
        # 総充電コネクタ接続検知回数
        if col in ("AllConnectionDetection_1", "AllConnectionDetection_2", "AllConnectionDetection_3", "AllConnectionDetection_4"):
            vehicle_no = row.get("VehicleNo")
            if col == "AllConnectionDetection_1":
                prev = 0
                if vehicle_no is not None and not df.empty and "VehicleNo" in df.columns and "AllConnectionDetection_1" in df.columns:
                    grp = df.loc[df["VehicleNo"] == vehicle_no, "AllConnectionDetection_1"]
                    if not grp.empty:
                        nums = pd.to_numeric(grp, errors="coerce")
                        if nums.notna().any():
                            prev = int(nums.max())
                # ChargeCnt に応じて AllConnectionDetection_1..4 を設定
                vals = [0, 0, 0, 0]  # index 0 -> _1, 1 -> _2, 2 -> _3, 3 -> _4
                if ChargeCnt == 4:
                    vals = [prev + 1, prev + 2, prev + 3, prev + 4]
                elif ChargeCnt == 3:
                    vals = [prev + 1, prev + 2, prev + 3, 0]
                elif ChargeCnt == 2:
                    vals = [prev + 1, prev + 2, 0, 0]
                elif ChargeCnt == 1:
                    vals = [prev + 1, 0, 0, 0]

                for idx, v in enumerate(vals, start=1):
                    colname = f"AllConnectionDetection_{idx}"
                    if colname in df.columns:
                        row[colname] = v
                continue
            
#            for i in range(ChargeCnt):
                if col == f"AllConnectionDetection_{i+1}":
                    vehicle_no = row.get("VehicleNo")
                    prev = 0
                    if vehicle_no is not None and not df.empty and "VehicleNo" in df.columns and col in df.columns:
                        grp = df[df["VehicleNo"] == vehicle_no][col]
                        if not grp.empty:
                            nums = pd.to_numeric(grp, errors="coerce")
                            if nums.notna().any():
                                prev = int(nums.max())
                    row[col] = prev + 1
                    continue
#            continue

        # インレット端子温度
        if col in ("Inlet_Terminal_Temp_C1_001", "Inlet_Terminal_Temp_C1_002", "Inlet_Terminal_Temp_C1_003", "Inlet_Terminal_Temp_C1_004","Inlet_Terminal_Temp_C1_005","Inlet_Terminal_Temp_C1_006","Inlet_Terminal_Temp_C1_007","Inlet_Terminal_Temp_C1_008", "Inlet_Terminal_Temp_C1_009", "Inlet_Terminal_Temp_C1_010"):
            # 一度だけ生成して 001～010 に割り当てる
            if not row.get("_inlet_generated"):
                # プロット数 = ChargeTime * 60 / 10
                plots = max(0, int(ChargeTime * 60 / 10))

                # 正規分布の中心はインデックス 6 (Inlet_Terminal_Temp_C1_006)
                mean_idx = 6.0
                sd = 1.5  # 標準偏差（必要なら調整）

                # 1..10 の位置に対する重みを計算して正規分布に従う確率に正規化
                positions = list(range(1, 11))
                weights = [math.exp(-0.5 * ((p - mean_idx) / sd) ** 2) for p in positions]
                total = sum(weights)
                probs = [w / total for w in weights] if total > 0 else [1.0 / 10] * 10

                # plots 回選んで各位置の出現回数をカウント（Multinomial の代替）
                picks = random.choices(positions, weights=probs, k=plots)
                counts = {p: 0 for p in positions}
                for p in picks:
                    counts[p] += 1

                # ChargeCnt に応じて Inlet_Terminal_Temp_C1_001..010 に対応する値を代入
                # ChargeCnt に応じて C1～C4 の各チャネルに同じ counts を割り当てる
                for ch in range(1, min(ChargeCnt, 4) + 1):
                    for i in positions:
                        colname = f"Inlet_Terminal_Temp_C{ch}_{i:03d}"
                        if colname in df.columns:
                            row[colname] = counts[i]


                # 各 Inlet_Terminal_Temp_C1_001..010 に対応する値を代入
                #for i in positions:
                #    colname = f"Inlet_Terminal_Temp_C1_{i:03d}" #このへんをChargeCntに対応すると、C2,C3,C4にも対応できる
                #    if colname in df.columns:
                #        row[colname] = counts[i]

                # フラグを立てて二重生成を防止（DataFrame には含められないキー）
                row["_inlet_generated"] = True

            # 以降ループで他の Inlet 列が来ても既に設定済みなのでスキップ
            if col in ("Inlet_Terminal_Temp_C1_001", "Inlet_Terminal_Temp_C1_002", "Inlet_Terminal_Temp_C1_003", "Inlet_Terminal_Temp_C1_004","Inlet_Terminal_Temp_C1_005","Inlet_Terminal_Temp_C1_006","Inlet_Terminal_Temp_C1_007","Inlet_Terminal_Temp_C1_008", "Inlet_Terminal_Temp_C1_009", "Inlet_Terminal_Temp_C1_010"):
                continue
        
        # CPLT Duty
        if col in ("CPLT_DUTY_C1_001", "CPLT_DUTY_C1_002", "CPLT_DUTY_C1_003", "CPLT_DUTY_C1_004","CPLT_DUTY_C1_005","CPLT_DUTY_C1_006","CPLT_DUTY_C1_007","CPLT_DUTY_C1_008", "CPLT_DUTY_C1_009", "CPLT_DUTY_C1_010","CPLT_DUTY_C1_011","CPLT_DUTY_C1_012","CPLT_DUTY_C1_013","CPLT_DUTY_C1_014","CPLT_DUTY_C1_015"):
            # 一度だけ生成して 001～010 に割り当てる
            if not row.get("_cplt_generated"):
                # プロット数 = ChargeTime * 60 / 10
                plots = max(0, int(ChargeTime * 60 / 10))

                # 一様分布で各位置に均等に分布させる
                positions = list(range(1, 16))
                counts = {p: 0 for p in positions}

                picks = random.choices(positions, k=plots)
                for p in picks:
                    counts[p] += 1

                # ChargeCnt に応じて C1～C4 の各チャネルに同じ counts を割り当てる
                for ch in range(1, min(ChargeCnt, 4) + 1):
                    for i in positions:
                        colname = f"CPLT_DUTY_C{ch}_{i:03d}"
                        if colname in df.columns:
                            row[colname] = counts[i]

                # 各 CPLT_DUTY_C1_001..010 に対応する値を代入
                #for i in positions:
                #    colname = f"CPLT_DUTY_C1_{i:03d}"
                #    if colname in df.columns:
                #        row[colname] = counts[i]

                # フラグを立てて二重生成を防止（DataFrame には含められないキー）
                row["_cplt_generated"] = True

            # 以降ループで他の CPLT 列が来ても既に設定済みなのでスキップ
            if col in ("CPLT_DUTY_C1_001", "CPLT_DUTY_C1_002", "CPLT_DUTY_C1_003", "CPLT_DUTY_C1_004","CPLT_DUTY_C1_005","CPLT_DUTY_C1_006","CPLT_DUTY_C1_007","CPLT_DUTY_C1_008", "CPLT_DUTY_C1_009", "CPLT_DUTY_C1_010","CPLT_DUTY_C1_011","CPLT_DUTY_C1_012","CPLT_DUTY_C1_013","CPLT_DUTY_C1_014","CPLT_DUTY_C1_015"):
                continue
        
        # PISW 電圧
        if col in ("PISW_Voltage_C1_001", "PISW_Voltage_C1_002", "PISW_Voltage_C1_003", "PISW_Voltage_C1_004","PISW_Voltage_C1_005"):
            # 一度だけ生成して PISW_Voltage_C1_001..005 に割り振る
            if not row.get("_pisw_generated"):
                # プロット数 = ChargeTime * 60 / 10
                plots = max(0, int(ChargeTime * 60 / 10))

                positions = list(range(1, 6))
                counts = {pos: 0 for pos in positions}

                if plots > 0:
                    picks = random.choices(positions, k=plots)
                    for p in picks:
                        counts[p] += 1

                # ChargeCnt に応じて C1～C4 の各チャネルに同じ counts を割り当てる
                for ch in range(1, min(ChargeCnt, 4) + 1):
                    for i in positions:
                        colname = f"PISW_Voltage_C{ch}_{i:03d}"
                        if colname in df.columns:
                            row[colname] = counts[i]

                # PISW_Voltage_C1_001..005 にのみ割り当て
                #for pos in positions:
                #    colname = f"PISW_Voltage_C1_{pos:03d}"
                #    if colname in df.columns:
                #        row[colname] = counts[pos]

                row["_pisw_generated"] = True
            continue
        
        # 充電最大電力
        if col in ("CHARGER_MAX_POWER_C1", "CHARGER_MAX_POWER_C2", "CHARGER_MAX_POWER_C3", "CHARGER_MAX_POWER_C4"):
            # 例えば 50kW 固定など、適宜調整可能
            for i in range(ChargeCnt):
                if col == f"CHARGER_MAX_POWER_C{i+1}":
                    row[col] = random.randint(50, 150)
                    break
            continue
        
        # 充電器入力電圧[V]
        if col in ("CHARGER_INPUT_VOLTAGE_C1_001", "CHARGER_INPUT_VOLTAGE_C1_002", "CHARGER_INPUT_VOLTAGE_C1_003", "CHARGER_INPUT_VOLTAGE_C1_004","CHARGER_INPUT_VOLTAGE_C1_005","CHARGER_INPUT_VOLTAGE_C1_006","CHARGER_INPUT_VOLTAGE_C1_007","CHARGER_INPUT_VOLTAGE_C1_008", "CHARGER_INPUT_VOLTAGE_C1_009"):
            # 一度だけ生成して 001～009 に割り当てる
            if not row.get("_charger_voltage_generated"):
                # プロット数 = ChargeTime * 60 / 10
                plots = max(0, int(ChargeTime * 60 / 10))

                positions = list(range(1, 10))
                counts = {p: 0 for p in positions}

                picks = random.choices(positions, k=plots)
                for p in picks:
                    counts[p] += 1

                # ChargeCnt に応じて C1～C4 の各チャネルに同じ counts を割り当てる
                for ch in range(1, min(ChargeCnt, 4) + 1):
                    for i in positions:
                        colname = f"CHARGER_INPUT_VOLTAGE_C{ch}_{i:03d}"
                        if colname in df.columns:
                            row[colname] = counts[i]

                # 各 CHARGER_INPUT_VOLTAGE_C1_001..009 に対応する値を代入
                #for i in positions:
                #    colname = f"CHARGER_INPUT_VOLTAGE_C1_{i:03d}"
                #    if colname in df.columns:
                #        row[colname] = counts[i]

                # フラグを立てて二重生成を防止（DataFrame には含められないキー）
                row["_charger_voltage_generated"] = True
            # 以降ループで他の CHARGER_INPUT_VOLTAGE 列が来ても既に設定済みなのでスキップ
            if col in ("CHARGER_INPUT_VOLTAGE_C1_001", "CHARGER_INPUT_VOLTAGE_C1_002", "CHARGER_INPUT_VOLTAGE_C1_003", "CHARGER_INPUT_VOLTAGE_C1_004","CHARGER_INPUT_VOLTAGE_C1_005","CHARGER_INPUT_VOLTAGE_C1_006","CHARGER_INPUT_VOLTAGE_C1_007","CHARGER_INPUT_VOLTAGE_C1_008", "CHARGER_INPUT_VOLTAGE_C1_009"):
                continue

        # 充電器出力電圧[V]
        if col in ("CHARGER_OUTPUT_VOLTAGE_C1_001", "CHARGER_OUTPUT_VOLTAGE_C1_002", "CHARGER_OUTPUT_VOLTAGE_C1_003", "CHARGER_OUTPUT_VOLTAGE_C1_004","CHARGER_OUTPUT_VOLTAGE_C1_005","CHARGER_OUTPUT_VOLTAGE_C1_006","CHARGER_OUTPUT_VOLTAGE_C1_007","CHARGER_OUTPUT_VOLTAGE_C1_008", "CHARGER_OUTPUT_VOLTAGE_C1_009"):
            # 一度だけ生成して 001～009 に割り当てる
            if not row.get("_charger_output_voltage_generated"):
                # プロット数 = ChargeTime * 60 / 10
                plots = max(0, int(ChargeTime * 60 / 10))

                positions = list(range(1, 10))
                counts = {p: 0 for p in positions}

                picks = random.choices(positions, k=plots)
                for p in picks:
                    counts[p] += 1

                # ChargeCnt に応じて C1～C4 の各チャネルに同じ counts を割り当てる
                for ch in range(1, min(ChargeCnt, 4) + 1):
                    for i in positions:
                        colname = f"CHARGER_OUTPUT_VOLTAGE_C{ch}_{i:03d}"
                        if colname in df.columns:
                            row[colname] = counts[i]

                # 各 CHARGER_OUTPUT_VOLTAGE_C1_001..009 に対応する値を代入
                #for i in positions:
                #    colname = f"CHARGER_OUTPUT_VOLTAGE_C1_{i:03d}"
                #    if colname in df.columns:
                #        row[colname] = counts[i]

                # フラグを立てて二重生成を防止（DataFrame には含められないキー）
                row["_charger_output_voltage_generated"] = True
            # 以降ループで他の CHARGER_OUTPUT_VOLTAGE 列が来ても既に設定済みなのでスキップ
            if col in ("CHARGER_OUTPUT_VOLTAGE_C1_001", "CHARGER_OUTPUT_VOLTAGE_C1_002", "CHARGER_OUTPUT_VOLTAGE_C1_003", "CHARGER_OUTPUT_VOLTAGE_C1_004","CHARGER_OUTPUT_VOLTAGE_C1_005","CHARGER_OUTPUT_VOLTAGE_C1_006","CHARGER_OUTPUT_VOLTAGE_C1_007","CHARGER_OUTPUT_VOLTAGE_C1_008", "CHARGER_OUTPUT_VOLTAGE_C1_009"):
                continue
            
        # 充電器出力[kw]
        if col in ("CHARGER_OUTPUT_POWER_C1_001", "CHARGER_OUTPUT_POWER_C1_002", "CHARGER_OUTPUT_POWER_C1_003", "CHARGER_OUTPUT_POWER_C1_004","CHARGER_OUTPUT_POWER_C1_005","CHARGER_OUTPUT_POWER_C1_006","CHARGER_OUTPUT_POWER_C1_007","CHARGER_OUTPUT_POWER_C1_008", "CHARGER_OUTPUT_POWER_C1_009"):
            # 一度だけ生成して 001～009 に割り当てる
            if not row.get("_charger_output_power_generated"):
                # プロット数 = ChargeTime * 60 / 10
                plots = max(0, int(ChargeTime * 60 / 10))

                positions = list(range(1, 10))
                counts = {p: 0 for p in positions}

                picks = random.choices(positions, k=plots)
                for p in picks:
                    counts[p] += 1

                # ChargeCnt に応じて C1～C4 の各チャネルに同じ counts を割り当てる
                for ch in range(1, min(ChargeCnt, 4) + 1):
                    for i in positions:
                        colname = f"CHARGER_OUTPUT_POWER_C{ch}_{i:03d}"
                        if colname in df.columns:
                            row[colname] = counts[i]

                # 各 CHARGER_OUTPUT_POWER_C1_001..009 に対応する値を代入
                #for i in positions:
                #    colname = f"CHARGER_OUTPUT_POWER_C1_{i:03d}"
                #    if colname in df.columns:
                #        row[colname] = counts[i]

                # フラグを立てて二重生成を防止（DataFrame には含められないキー）
                row["_charger_output_power_generated"] = True
            # 以降ループで他の CHARGER_OUTPUT_POWER 列が来ても既に設定済みなのでスキップ
            if col in ("CHARGER_OUTPUT_POWER_C1_001", "CHARGER_OUTPUT_POWER_C1_002", "CHARGER_OUTPUT_POWER_C1_003", "CHARGER_OUTPUT_POWER_C1_004","CHARGER_OUTPUT_POWER_C1_005","CHARGER_OUTPUT_POWER_C1_006","CHARGER_OUTPUT_POWER_C1_007","CHARGER_OUTPUT_POWER_C1_008", "CHARGER_OUTPUT_POWER_C1_009"):
                continue
            
        # 充電中電流（時系列）
        if col in ("IN_CHARGE_CURRENT_001", "IN_CHARGE_CURRENT_002", "IN_CHARGE_CURRENT_003", "IN_CHARGE_CURRENT_004","IN_CHARGE_CURRENT_005","IN_CHARGE_CURRENT_006","IN_CHARGE_CURRENT_007","IN_CHARGE_CURRENT_008","IN_CHARGE_CURRENT_009","IN_CHARGE_CURRENT_010"):
            # 時系列 IN_CHARGE_CURRENT_001..010 を一度だけ生成して同じ値を各ラベルに設定
            if not row.get("_in_charge_current_generated"): 
                val = random.randint(400.0, 500.0)
                for i in range(1, 11):
                    colname = f"IN_CHARGE_CURRENT_{i:03d}"
                    if colname in df.columns:
                        row[colname] = val
                row["_in_charge_current_generated"] = True
            continue

        # 充電中Win（時系列）
        if col in ("IN_CHARGE_WIN_001", "IN_CHARGE_WIN_002", "IN_CHARGE_WIN_003", "IN_CHARGE_WIN_004","IN_CHARGE_WIN_005","IN_CHARGE_WIN_006","IN_CHARGE_WIN_007","IN_CHARGE_WIN_008","IN_CHARGE_WIN_009","IN_CHARGE_WIN_010"):
            if not row.get("_in_charge_win_generated"):
                val = random.randint(50.0, 300.0)
                for i in range(1, 11):
                    colname = f"IN_CHARGE_WIN_{i:03d}"
                    if colname in df.columns:
                        row[colname] = val
                row["_in_charge_win_generated"] = True
            continue

        # 充電中SOC（時系列）
        if col in ("IN_CHARGE_SOC_001", "IN_CHARGE_SOC_002", "IN_CHARGE_SOC_003", "IN_CHARGE_SOC_004","IN_CHARGE_SOC_005","IN_CHARGE_SOC_006","IN_CHARGE_SOC_007","IN_CHARGE_SOC_008","IN_CHARGE_SOC_009","IN_CHARGE_SOC_010"):
            if not row.get("_in_charge_soc_generated"):
                val = random.randint(50.0, 80.0)
                for i in range(1, 11):
                    colname = f"IN_CHARGE_SOC_{i:03d}"
                    if colname in df.columns:
                        row[colname] = val
                row["_in_charge_soc_generated"] = True
            continue

        # DCリレー温度[℃]
        if col in ("DC_RELAY_TEMP_C1_001", "DC_RELAY_TEMP_C1_002", "DC_RELAY_TEMP_C1_003", "DC_RELAY_TEMP_C1_004","DC_RELAY_TEMP_C1_005","DC_RELAY_TEMP_C1_006","DC_RELAY_TEMP_C1_007","DC_RELAY_TEMP_C1_008"):
            # 一度だけ生成して 001～010 に割り当てる
            if not row.get("_dc_relay_generated"):
                # プロット数 = ChargeTime * 60 / 10
                plots = max(0, int(ChargeTime * 60 / 10))

                positions = list(range(1, 11))
                counts = {p: 0 for p in positions}

                picks = random.choices(positions, k=plots)
                for p in picks:
                    counts[p] += 1

                # ChargeCnt に応じて C1～C4 の各チャネルに同じ counts を割り当てる
                for ch in range(1, min(ChargeCnt, 4) + 1):
                    for i in positions:
                        colname = f"DC_RELAY_TEMP_C{ch}_{i:03d}"
                        if colname in df.columns:
                            row[colname] = counts[i]
                
                # 各 DC_RELAY_TEMP_C1_001..010 に対応する値を代入
                #for i in positions:
                #    colname = f"DC_RELAY_TEMP_C1_{i:03d}"
                #    if colname in df.columns:
                #        row[colname] = counts[i]

                # フラグを立てて二重生成を防止（DataFrame には含められないキー）
                row["_dc_relay_generated"] = True

            # 以降ループで他の DC_RELAY 列が来ても既に設定済みなのでスキップ
            if col in ("DC_RELAY_TEMP_C1_001", "DC_RELAY_TEMP_C1_002", "DC_RELAY_TEMP_C1_003", "DC_RELAY_TEMP_C1_004","DC_RELAY_TEMP_C1_005","DC_RELAY_TEMP_C1_006","DC_RELAY_TEMP_C1_007","DC_RELAY_TEMP_C1_008"):
                continue
            
        # ACリレー温度[℃]
        if col in ("AC_RELAY_TEMP_C1_001", "AC_RELAY_TEMP_C1_002", "AC_RELAY_TEMP_C1_003", "AC_RELAY_TEMP_C1_004","AC_RELAY_TEMP_C1_005","AC_RELAY_TEMP_C1_006","AC_RELAY_TEMP_C1_007","AC_RELAY_TEMP_C1_008"):
            # 一度だけ生成して 001～010 に割り当てる
            if not row.get("_ac_relay_generated"):
                # プロット数 = ChargeTime * 60 / 10
                plots = max(0, int(ChargeTime * 60 / 10))

                positions = list(range(1, 11))
                counts = {p: 0 for p in positions}

                picks = random.choices(positions, k=plots)
                for p in picks:
                    counts[p] += 1

                # ChargeCnt に応じて C1～C4 の各チャネルに同じ counts を割り当てる
                for ch in range(1, min(ChargeCnt, 4) + 1):
                    for i in positions:
                        colname = f"AC_RELAY_TEMP_C{ch}_{i:03d}"
                        if colname in df.columns:
                            row[colname] = counts[i]

                # 各 AC_RELAY_TEMP_C1_001..010 に対応する値を代入
                #for i in positions:
                #    colname = f"AC_RELAY_TEMP_C1_{i:03d}"
                #    if colname in df.columns:
                #        row[colname] = counts[i]

                # フラグを立てて二重生成を防止（DataFrame には含められないキー）
                row["_ac_relay_generated"] = True

            # 以降ループで他の AC_RELAY 列が来ても既に設定済みなのでスキップ
            if col in ("AC_RELAY_TEMP_C1_001", "AC_RELAY_TEMP_C1_002", "AC_RELAY_TEMP_C1_003", "AC_RELAY_TEMP_C1_004","AC_RELAY_TEMP_C1_005","AC_RELAY_TEMP_C1_006","AC_RELAY_TEMP_C1_007","AC_RELAY_TEMP_C1_008"):
                continue

        # 充電中セル最大温度（時系列）
        if col in ("IN_CHARGE_CELL_MAX_TEMP_001", "IN_CHARGE_CELL_MAX_TEMP_002", "IN_CHARGE_CELL_MAX_TEMP_003", "IN_CHARGE_CELL_MAX_TEMP_004","IN_CHARGE_CELL_MAX_TEMP_005","IN_CHARGE_CELL_MAX_TEMP_006","IN_CHARGE_CELL_MAX_TEMP_007","IN_CHARGE_CELL_MAX_TEMP_008","IN_CHARGE_CELL_MAX_TEMP_009","IN_CHARGE_CELL_MAX_TEMP_010"):
            if not row.get("_in_charge_cell_max_temp_generated"):
                val = random.randint(40.0, 60.0)
                for i in range(1, 11):
                    colname = f"IN_CHARGE_CELL_MAX_TEMP_{i:03d}"
                    if colname in df.columns:
                        row[colname] = val
                row["_in_charge_cell_max_temp_generated"] = True
            continue

        # 充電中セル最小温度（時系列）
        if col in ("IN_CHARGE_CELL_MIN_TEMP_001", "IN_CHARGE_CELL_MIN_TEMP_002", "IN_CHARGE_CELL_MIN_TEMP_003", "IN_CHARGE_CELL_MIN_TEMP_004","IN_CHARGE_CELL_MIN_TEMP_005","IN_CHARGE_CELL_MIN_TEMP_006","IN_CHARGE_CELL_MIN_TEMP_007","IN_CHARGE_CELL_MIN_TEMP_008","IN_CHARGE_CELL_MIN_TEMP_009","IN_CHARGE_CELL_MIN_TEMP_010"):
            if not row.get("_in_charge_cell_min_temp_generated"):
                val = random.randint(30.0, 40.0)
                for i in range(1, 11):
                    colname = f"IN_CHARGE_CELL_MIN_TEMP_{i:03d}"
                    if colname in df.columns:
                        row[colname] = val
                row["_in_charge_cell_min_temp_generated"] = True
            continue

        # 総AC充電電力量
        if col in ("AC_CHARGE_POWER_AMOUNT"):
            row[col] = random.randint(100, 500)
            continue

        # 総DC充電電力量
        if col in ("DC_CHARGE_POWER_AMOUNT"):
            row[col] = random.randint(500, 1000)
            continue
        
        # 総充電時間[min]
        if col in ("CHARGE_TIME_AMOUNT"):
            row[col] = random.randint(10000, 50000)
            continue
        
        # DC充電回数
        if col in ("DC_CHARGE_COUNTS"):
            row[col] = random.randint(50, 600)
            continue
        
        # AC充電回数
        if col in ("AC_CHARGE_COUNTS"):
            row[col] = random.randint(200, 800)
            continue
        
        # 充電停止要因
        if col in ("CHARGE_STOP_COUNT_C1_001", "CHARGE_STOP_COUNT_C1_002", "CHARGE_STOP_COUNT_C1_003", "CHARGE_STOP_COUNT_C1_004"):
            # CHARGE_STOP_COUNT_C{ch}_{001..004} と CHARGE_STOP_COUNT_C{ch} を 0 に設定（存在する列のみ）
            for ch in range(1, 5):
                for i in range(1, 5):
                    detailed_col = f"CHARGE_STOP_COUNT_C{ch}_{i:03d}"
                    if detailed_col in df.columns:
                        row[detailed_col] = 0
            continue
        
        # EVSE_MAlfuction
        if col in ("EVSE_MAlfuction_C1", "EVSE_MAlfuction_C2", "EVSE_MAlfuction_C3", "EVSE_MAlfuction_C4"):
            row[col] = 0
            continue
        
        # EVSE_Shutdown
        if col in ("EVSE_Shutdown_C1", "EVSE_Shutdown_C2", "EVSE_Shutdown_C3", "EVSE_Shutdown_C4"):
            row[col] = 0
            continue
        
        # EVSE_UtilityInterruptEvent
        if col in ("EVSE_UtilityInterruptEvent_C1", "EVSE_UtilityInterruptEvent_C2", "EVSE_UtilityInterruptEvent_C3", "EVSE_UtilityInterruptEvent_C4"):
            row[col] = 0
            continue
        
        #　ERROR系各種。一旦は0固定
        cols = [
            "FAILED_C1_001", "FAILED_C2_001", "FAILED_C3_001", "FAILED_C4_001", \
            "FAILED_C1_002", "FAILED_C2_002", "FAILED_C3_002", "FAILED_C4_002", \
            "FAILED_C1_003", "FAILED_C2_003", "FAILED_C3_003", "FAILED_C4_003", \
            "FAILED_C1_004", "FAILED_C2_004", "FAILED_C3_004", "FAILED_C4_004", \
            "FAILED_C1_005", "FAILED_C2_005", "FAILED_C3_005", "FAILED_C4_005", \
            "FAILED_C1_006", "FAILED_C2_006", "FAILED_C3_006", "FAILED_C4_006", \
            "FAILED_C1_007", "FAILED_C2_007", "FAILED_C3_007", "FAILED_C4_007", \
            "FAILED_C1_008", "FAILED_C2_008", "FAILED_C3_008", "FAILED_C4_008", \
            "FAILED_C1_009", "FAILED_C2_009", "FAILED_C3_009", "FAILED_C4_009", \
            "FAILED_C1_010", "FAILED_C2_010", "FAILED_C3_010", "FAILED_C4_010", \
                
            "FAILED_C1_011", "FAILED_C2_011", "FAILED_C3_011", "FAILED_C4_011", \
            "FAILED_C1_012", "FAILED_C2_012", "FAILED_C3_012", "FAILED_C4_012", \
            "FAILED_C1_013", "FAILED_C2_013", "FAILED_C3_013", "FAILED_C4_013", \
            "FAILED_C1_014", "FAILED_C2_014", "FAILED_C3_014", "FAILED_C4_014", \
            "FAILED_C1_015", "FAILED_C2_015", "FAILED_C3_015", "FAILED_C4_015", \
            "FAILED_C1_016", "FAILED_C2_016", "FAILED_C3_016", "FAILED_C4_016", \
            "FAILED_C1_017", "FAILED_C2_017", "FAILED_C3_017", "FAILED_C4_017", \
            "FAILED_C1_018", "FAILED_C2_018", "FAILED_C3_018", "FAILED_C4_018", \
            "FAILED_C1_019", "FAILED_C2_019", "FAILED_C3_019", "FAILED_C4_019", \
            "FAILED_C1_020", "FAILED_C2_020", "FAILED_C3_020", "FAILED_C4_020", \

            "FAILED_C1_021", "FAILED_C2_021", "FAILED_C3_021", "FAILED_C4_021", \
            "FAILED_C1_022", "FAILED_C2_022", "FAILED_C3_022", "FAILED_C4_022", \
            "FAILED_C1_023", "FAILED_C2_023", "FAILED_C3_023", "FAILED_C4_023", \
            "FAILED_C1_024", "FAILED_C2_024", "FAILED_C3_024", "FAILED_C4_024", \
            "FAILED_C1_025", "FAILED_C2_025", "FAILED_C3_025", "FAILED_C4_025", \
            "FAILED_C1_026", "FAILED_C2_026", "FAILED_C3_026", "FAILED_C4_026", \
            "FAILED_C1_027", "FAILED_C2_027", "FAILED_C3_027", "FAILED_C4_027", \
            "FAILED_C1_028", "FAILED_C2_028", "FAILED_C3_028", "FAILED_C4_028", \
            "FAILED_C1_029", "FAILED_C2_029", "FAILED_C3_029", "FAILED_C4_029", \
            "FAILED_C1_030", "FAILED_C2_030", "FAILED_C3_030", "FAILED_C4_030", \

            "FAILED_C1_031", "FAILED_C2_031", "FAILED_C3_031", "FAILED_C4_031", \
            "FAILED_C1_032", "FAILED_C2_032", "FAILED_C3_032", "FAILED_C4_032", \
            "FAILED_C1_033", "FAILED_C2_033", "FAILED_C3_033", "FAILED_C4_033", \
            "FAILED_C1_034", "FAILED_C2_034", "FAILED_C3_034", "FAILED_C4_034", \
        ]
        for i in cols:
            row[i] = 0
            
        # 今回充電時間
        if col in ("CHARGING_TIME_C1"):
            for i in range(ChargeCnt):
                if col == f"CHARGING_TIME_C{i+1}":
                    row[col] = ChargeTime + random.randint(-5, 5)
                    break
            continue
        
        # 今回充電電力量
        if col in ("CHARGING_POWER_C1","CHARGING_POWER_C2","CHARGING_POWER_C3","CHARGING_POWER_C4"):
            for i in range(ChargeCnt):
                if col == f"CHARGING_POWER_C{i+1}":
                    # 50 kW で充電したと仮定（充電エネルギー[kWh] = 50[kW] * ChargeTime[h]）
                    base_power = (ChargeTime / 60.0) * 50.0
                    variation = random.uniform(-0.1, 0.1) * base_power
                    row[col] = round(max(0.0, base_power + variation), 2)
                    break
            continue
        
        #ACDC充電成功失敗回数
        if col in ("AC_CHARGE_SUCESSED_COUNT","AC_CHARGE_FAILED_COUNT","DC_CHARGE_SUCESSED_COUNT","DC_CHARGE_FAILED_COUNT"):
            if col == "AC_CHARGE_SUCESSED_COUNT":
                if ACDCFLG == 0:
                    prev = 0
                    if not df.empty and col in df.columns:
                        nums = pd.to_numeric(df[col], errors="coerce")
                        if nums.notna().any():
                            prev = int(nums.max())
                    row[col] = prev + 1
                else:
                    row[col] = 0
                continue

            if col == "AC_CHARGE_FAILED_COUNT":
                row[col] = 0
                continue

            if col == "DC_CHARGE_SUCESSED_COUNT":
                if ACDCFLG != 0:
                    prev = 0
                    if not df.empty and col in df.columns:
                        nums = pd.to_numeric(df[col], errors="coerce")
                        if nums.notna().any():
                            prev = int(nums.max())
                    row[col] = prev + 1
                else:
                    row[col] = 0
                continue

            if col == "DC_CHARGE_FAILED_COUNT":
                row[col] = 0
                continue
            continue
    
        # 充電モードフラグ
        if col in ("CHARGE_MODE_NORMAL_FLAG_C1","CHARGE_MODE_TIMER_FLAG_C1"):
            # 両フラグを同時に決定して矛盾を防ぐ
            timer_flag = 0
            if ACDCFLG == 0:
                # 50% の確率でタイマーフラグを立てる
                timer_flag = int(random.random() < 0.5)
            else:
                # ACDCFLG が 1 のときはタイマーフラグは 0
                timer_flag = 0

            # タイマーフラグが 1 のときはノーマルフラグを 0、それ以外は 1
            normal_flag = 0 if timer_flag == 1 else 1

            # CHARGE_MODE_* を ChargeCnt 分（C1..C4）に適用
            for ch in range(1, min(max(1, int(ChargeCnt)), 4) + 1):
                tcol = f"CHARGE_MODE_TIMER_FLAG_C{ch}"
                ncol = f"CHARGE_MODE_NORMAL_FLAG_C{ch}"
                if tcol in df.columns:
                    row[tcol] = timer_flag
                if ncol in df.columns:
                    row[ncol] = normal_flag
            continue
        
        #　充電時間
        if col in ("CHARGING_TIME_C1", "CHARGING_TIME_C2", "CHARGING_TIME_C3", "CHARGING_TIME_C4"):
            row[col] = ChargeTime
            # 他のチャネルの充電時間を ChargeTime ±20 で設定（存在する列のみ）
            for i in range(2, 5):
                cname = f"CHARGING_TIME_C{i}"
                if cname in df.columns:
                    val = ChargeTime + random.randint(-20, 20)
                    row[cname] = max(0, int(val))
            continue
        
        # 充電電力量
        if col in ("CHARGING_POWER_C1", "CHARGING_POWER_C2", "CHARGING_POWER_C3", "CHARGING_POWER_C4"):
            # 仮に ChargeTime * 0.5 kWh として、他のチャネルも同様に設定
            # 50 kW で充電したと仮定（充電エネルギー[kWh] = 50[kW] * ChargeTime[h]）
            base_power = (ChargeTime / 60.0) * 50.0
            row[col] = round(base_power, 2)
            for i in range(2, 5):
                cname = f"CHARGING_POWER_C{i}"
                if cname in df.columns:
                    variation = random.uniform(-0.1, 0.1) * base_power
                    row[cname] = round(max(0.0, base_power + variation), 2)
            continue
        
        # 今回充電のACDCの成功失敗フラグ
        if col in ("AC_CHARGE_SUCESSED_FLAG_C1","DC_CHARGE_SUCESSED_FLAG_C1","AC_CHARGE_FAILED_FLAG_C1","DC_CHARGE_FAILED_FLAG_C1"):
            # Decide success (80%) vs failure (20%) once per record and reuse
            if "_charge_success" not in row:
                row["_charge_success"] = random.random() < 0.8
            success = row["_charge_success"]

            if col in ("AC_CHARGE_SUCESSED_FLAG_C1","AC_CHARGE_FAILED_FLAG_C1","DC_CHARGE_SUCESSED_FLAG_C1","DC_CHARGE_FAILED_FLAG_C1"):
                # 決定した success と ACDCFLG に基づき各フラグを排他的に設定
                if ACDCFLG == 0 and success:
                    vals = (1, 0, 0, 0)
                elif ACDCFLG == 0 and not success:
                    vals = (0, 1, 0, 0)
                elif ACDCFLG != 0 and success:
                    vals = (0, 0, 1, 0)
                else:
                    vals = (0, 0, 0, 1)

                # Apply the same exclusive-success/failure mapping for each channel up to ChargeCnt (max 4)
                for ch in range(1, min(max(1, int(ChargeCnt)), 4) + 1):
                    if ACDCFLG == 0 and success:
                        ac_succ, ac_fail, dc_succ, dc_fail = 1, 0, 0, 0
                    elif ACDCFLG == 0 and not success:
                        ac_succ, ac_fail, dc_succ, dc_fail = 0, 1, 0, 0
                    elif ACDCFLG != 0 and success:
                        ac_succ, ac_fail, dc_succ, dc_fail = 0, 0, 1, 0
                    else:
                        ac_succ, ac_fail, dc_succ, dc_fail = 0, 0, 0, 1

                    mapping_ch = {
                        f"AC_CHARGE_SUCESSED_FLAG_C{ch}": ac_succ,
                        f"AC_CHARGE_FAILED_FLAG_C{ch}":   ac_fail,
                        f"DC_CHARGE_SUCESSED_FLAG_C{ch}": dc_succ,
                        f"DC_CHARGE_FAILED_FLAG_C{ch}":   dc_fail,
                    }

                    for k, v in mapping_ch.items():
                        if k in df.columns:
                            row[k] = v

                #mapping = {
                #    "AC_CHARGE_SUCESSED_FLAG_C1": vals[0],
                #    "AC_CHARGE_FAILED_FLAG_C1":   vals[1],
                #    "DC_CHARGE_SUCESSED_FLAG_C1": vals[2],
                #    "DC_CHARGE_FAILED_FLAG_C1":   vals[3],
                #}
                #for k, v in mapping.items():
                #    if k in df.columns:
                #        row[k] = v
                
                continue
            continue
                
        if col.endswith("_flag") or col.startswith("is_"):
            row[col] = False
            continue
        if col in ("status", "state"):
            row[col] = "unknown"
            continue
        
        # GPS
        if col in ("GPS_LATITUDE_DEGREES", "GPS_LATITUDE_MINUTES", "GPS_LATITUDE_SECONDS",
                   "GPS_LONGITUDE_DEGREES", "GPS_LONGITUDE_MINUTES", "GPS_LONGITUDE_SECONDS"): 
            # 中心は約 36.5N, -117.0 (Death Valley 周辺)
            max_miles = 400.0
            earth_radius_miles = 3958.8
            rand_r = max_miles * math.sqrt(random.random())  # 面積均等
            bearing = random.uniform(0.0, 2.0 * math.pi)
            lat1 = math.radians(36.5)
            lon1 = math.radians(-117.0)
            ang_dist = rand_r / earth_radius_miles
            lat2 = math.asin(math.sin(lat1) * math.cos(ang_dist) + math.cos(lat1) * math.sin(ang_dist) * math.cos(bearing))
            lon2 = lon1 + math.atan2(math.sin(bearing) * math.sin(ang_dist) * math.cos(lat1),
                                        math.cos(ang_dist) - math.sin(lat1) * math.sin(lat2))
            dec_lat = math.degrees(lat2)
            dec_lon = math.degrees(lon2)
            def _dec_to_dms(value):

                sign = -1 if value < 0 else 1
                a = abs(value)
                deg = int(math.floor(a))
                minutes = int(math.floor((a - deg) * 60.0))
                seconds = round((a - deg - minutes / 60.0) * 3600.0, 3)
                return int(deg * sign), minutes, seconds
            lat_deg_val, lat_min_val, lat_sec_val = _dec_to_dms(dec_lat)
            lon_deg_val, lon_min_val, lon_sec_val = _dec_to_dms(dec_lon)
            gps_mapping = {
                "GPS_LATITUDE_DEGREES": lat_deg_val,
                "GPS_LATITUDE_MINUTES": lat_min_val,
                "GPS_LATITUDE_SECONDS": lat_sec_val,
                "GPS_LONGITUDE_DEGREES": lon_deg_val,
                "GPS_LONGITUDE_MINUTES": lon_min_val,
                "GPS_LONGITUDE_SECONDS": lon_sec_val,
            }
            for k, v in gps_mapping.items():
                if k == col:
                    row[k] = v
            
            continue
        
        # SOC
        if col == "SOC":
            row[col] = random.randint(20, 80)
            continue
        
        #Mileage
        if col == "Mileage":
            row[col] = random.randint(10000, 100000)
            continue
        
        #VEHICLE_SPEED
        if col == "VEHICLE_SPEED":
            row[col] = random.randint(0, 120)
            continue
        
        #OUTSIDE_TEMP
        if col == "OUTSIDE_TEMP":
            row[col] = random.randint(-10, 35)
            continue
        
        #P_RANGE_STATUS
        if col == "P_RANGE_STATUS":
            row[col] = random.randint(0, 1)
            continue
        
        #HVB_AUX_VOLTAGE
        if col == "HVB_AUX_VOLTAGE":
            row[col] = round(random.uniform(12.0, 14.5), 2)
            continue
        
        #DC_RELAY_FAIL_NOTIFICATION
        if col == "DC_RELAY_FAIL_NOTIFICATION":
            row[col] = random.randint(0, 1)
            continue
        
        #BAT_PACK_TEMP_ERROR_NOTIFICATION
        if col == "BAT_PACK_TEMP_ERROR_NOTIFICATION":
            row[col] = random.randint(0, 1)
            continue
        
        #BMS_ERROR
        if col == "BMS_ERROR":
            row[col] = random.randint(0, 1)
            continue
        
        #CHARGER_STATUS
        if col == "CHARGER_STATUS":
            row[col] = 0
            continue
        
        #OBC_CHARGE_POSSIBLE_STATUS
        if col == "OBC_CHARGE_POSSIBLE_STATUS":
            row[col] = random.randint(0, 1)
            continue
        
        #EVCC_CNTRL_STATUS
        if col == "EVCC_CNTRL_STATUS":
            row[col] = random.choice([0, 10, 21, 22, 23, 41, 42, 43, 50, 60])
            continue
        
        #EVCC_WARINING
        if col == "EVCC_WARINING":
            row[col] = random.randint(0, 1)
            continue
        
        #CONNECTER_LOCK_ERROR
        if col == "CONNECTER_LOCK_ERROR":
            row[col] = random.randint(0, 1)
            continue
        
        #CELL_MAXIMUM_TEMP
        if col == "CELL_MAXIMUM_TEMP":
            row[col] = round(random.uniform(30.0, 35.0), 1)
            continue
        
        #CELL_MINIMUM_TEMP
        if col == "CELL_MINIMUM_TEMP":
            row[col] = round(random.uniform(25.0, 30.0), 1)
            continue

    new_row = pd.DataFrame([row], columns=df.columns)
    for k, dtype in df.dtypes.items():
        try:
            new_row[k] = new_row[k].astype(dtype)
        except Exception:
            pass

    return pd.concat([df, new_row], ignore_index=True)


def make_df_record_CAN(df: pd.DataFrame, vehicleNo: int, date_str: str, ChargeTime: int) -> pd.DataFrame:
    if df is None:
        return df
    
    # レコード数: ChargeTime　1分ごとに1レコード
    n_records = max(1, int(ChargeTime * 1))
    


    
    # SOC と完全一致する列を検出（大文字小文字は区別）
    soc_cols = []
    for col in df.columns:
        if col == "SOC":
            soc_cols.append(col)
    if not soc_cols:
        return df


    # GPSデータ（Death Valley 中心、半径400mile の範囲でランダム点を生成し D/M/S に分解）
    # 中心は約 36.5N, -117.0 (Death Valley 周辺)
    max_miles = 400.0
    earth_radius_miles = 3958.8

    rand_r = max_miles * math.sqrt(random.random())  # 面積均等
    bearing = random.uniform(0.0, 2.0 * math.pi)

    lat1 = math.radians(36.5)
    lon1 = math.radians(-117.0)
    ang_dist = rand_r / earth_radius_miles

    lat2 = math.asin(math.sin(lat1) * math.cos(ang_dist) + math.cos(lat1) * math.sin(ang_dist) * math.cos(bearing))
    lon2 = lon1 + math.atan2(math.sin(bearing) * math.sin(ang_dist) * math.cos(lat1),
                             math.cos(ang_dist) - math.sin(lat1) * math.sin(lat2))

    dec_lat = math.degrees(lat2)
    dec_lon = math.degrees(lon2)

    def _dec_to_dms(value):
        sign = -1 if value < 0 else 1
        a = abs(value)
        deg = int(math.floor(a))
        minutes = int(math.floor((a - deg) * 60.0))
        seconds = round((a - deg - minutes / 60.0) * 3600.0, 3)
        return int(deg * sign), minutes, seconds

    lat_deg_val, lat_min_val, lat_sec_val = _dec_to_dms(dec_lat)
    lon_deg_val, lon_min_val, lon_sec_val = _dec_to_dms(dec_lon)

    # n_records 個分のリスト（セッション内は同地点を繰り返す）
    gps_lat_deg_list = [lat_deg_val] * n_records
    gps_lat_min_list = [lat_min_val] * n_records
    gps_lat_sec_list = [lat_sec_val] * n_records
    gps_lon_deg_list = [lon_deg_val] * n_records
    gps_lon_min_list = [lon_min_val] * n_records
    gps_lon_sec_list = [lon_sec_val] * n_records

    # 次に作られる DataFrame（new_df）の生成時に一度だけ列へ代入するフックを設定
    _orig_pd_DataFrame = pd.DataFrame

    def _pd_df_hook(*args, **kwargs):
        df_created = _orig_pd_DataFrame(*args, **kwargs)
        # 列が存在すればレコード長に合わせて値を割当（存在しない列は無視）
        L = len(gps_lat_deg_list)
        if "GPS_LATITUDE_DEGREES" in df_created.columns:
            df_created["GPS_LATITUDE_DEGREES"] = gps_lat_deg_list[:L]
        if "GPS_LATITUDE_MINUTES" in df_created.columns:
            df_created["GPS_LATITUDE_MINUTES"] = gps_lat_min_list[:L]
        if "GPS_LATITUDE_SECONDS" in df_created.columns:
            df_created["GPS_LATITUDE_SECONDS"] = gps_lat_sec_list[:L]
        if "GPS_LONGITUDE_DEGREES" in df_created.columns:
            df_created["GPS_LONGITUDE_DEGREES"] = gps_lon_deg_list[:L]
        if "GPS_LONGITUDE_MINUTES" in df_created.columns:
            df_created["GPS_LONGITUDE_MINUTES"] = gps_lon_min_list[:L]
        if "GPS_LONGITUDE_SECONDS" in df_created.columns:
            df_created["GPS_LONGITUDE_SECONDS"] = gps_lon_sec_list[:L]
        # フックは一回だけ有効にして元に戻す
        pd.DataFrame = _orig_pd_DataFrame
        return df_created

    pd.DataFrame = _pd_df_hook

    # 初期SOC: 80..100
    init_soc = random.randint(80, 100)

    # 減少量のレンジを ChargeTime に応じて線形補間（30 -> 5..15, 60 -> 15..30）
    t = (ChargeTime - 30) / 30.0
    t = max(0.0, min(1.0, t))
    drop_min = 5 + t * 10   # 5 .. 15
    drop_max = 15 + t * 15  # 15 .. 30
    drop_min_i = max(0, int(math.floor(drop_min)))
    drop_max_i = max(drop_min_i, int(math.ceil(drop_max)))
    total_drop = random.randint(drop_min_i, drop_max_i)

    # 最終値は 0 未満にならないようにする
    final_soc = max(0, init_soc - total_drop)

    # 端から端まで減少する系列を作成（単調減少、整数、0..100 にクランプ）
    vals = []
    if n_records == 1:
        vals = [init_soc]
    else:
        for i in range(n_records):
            frac = i / (n_records - 1)
            v = init_soc - total_drop * frac
            vi = int(round(v))
            vi = max(0, min(100, vi))
            vals.append(vi)

    # DataFrame 用の行を作成（SOC 列に値を入れ、他列は欠損値）
    rows = []
    for v in vals:
        row = {c: None for c in df.columns}
        for sc in soc_cols:
            row[sc] = v
        rows.append(row)
        
    # 走行距離
    # "Mileage" 列を SOC と同様に線形補間で埋める
    mileage_cols = [c for c in df.columns if c == "Mileage"]
    if mileage_cols:
        init_mileage = random.randint(1000, 5000)
        # 増加量は ChargeTime に依存させる（単位: km）。必要に応じてレンジを調整。
        per_min = random.uniform(0.0, 0.8)  # 1分あたりの増分範囲
        total_increase = per_min * ChargeTime

        if n_records == 1:
            mileage_vals = [int(round(init_mileage))]
        else:
            mileage_vals = []
            for i in range(n_records):
                frac = i / (n_records - 1)
                v = init_mileage + total_increase * frac
                mileage_vals.append(int(round(v)))

        # rows に割り当て
        for idx, m in enumerate(mileage_vals):
            for mc in mileage_cols:
                rows[idx][mc] = m
                
    # 車速
    vehicle_speed_cols = [c for c in df.columns if c == "VEHICLE_SPEED"]
    if vehicle_speed_cols:
        # プロット数は SOC と同じ (rows の長さ = n_records)
        for idx in range(len(rows)):
            # 各プロットごとに 0..70 のランダム速度を設定
            speed = random.randint(0, 70)
            for vc in vehicle_speed_cols:
                rows[idx][vc] = speed

    new_df = pd.DataFrame(rows, columns=df.columns)
    
    #外気温
    # 外気温 ("OUTSIDE_TEMP" を優先して検出、その他の候補も許容)
    ambient_cols = [
        c for c in df.columns
        if c.upper() == "OUTSIDE_TEMP"
    ]
    if ambient_cols:
        # セッション（この new_df ブロック）ごとに一つの乱数を生成して全レコードに同じ値を入れる
        ambient_val = round(random.uniform(-10.0, 40.0), 1)  # 例: -10.0～40.0℃のランダム値（小数1桁）
        for col in ambient_cols:
            new_df[col] = ambient_val
            
    #　Pレンジ状態
    # Collect columns whose name matches "P_RANGE_STATUS" (case-insensitive, ignores surrounding whitespace)
    p_range_cols = []
    target = "P_RANGE_STATUS"
    for col in df.columns:
        if isinstance(col, str) and col.strip().upper() == target:
            p_range_cols.append(col)
    if p_range_cols:
        vals = [random.randint(0, 1) for _ in range(len(new_df))]
        for col in p_range_cols:
            new_df[col] = vals

    # 補機電圧: HVB_AUX_VOLTAGE を 13.5～14.5 のランダム値で埋める（レコードごとにランダム）
    aux_cols = [c for c in df.columns if isinstance(c, str) and c.strip().upper() == "HVB_AUX_VOLTAGE"]
    if aux_cols:
        vals = [round(random.uniform(13.5, 14.5), 2) for _ in range(len(new_df))]
        for col in aux_cols:
            new_df[col] = vals
            
    # DC電圧リレー故障通知、電池パック過温度通知、BMSコネクタ過熱通知
    # これらの列は、"DC_VOLTAGE_RELAY_FAULT", "BATTERY_PACK_OVERTEMPERATURE", "BMS_CONNECTOR_OVERHEAT" と仮定
    fault_cols = [
        [c for c in df.columns if isinstance(c, str) and c.strip().upper() == "DC_RELAY_FAIL_NOTIFICATION"],
        [c for c in df.columns if isinstance(c, str) and c.strip().upper() == "BAT_PACK_TEMP_ERROR_NOTIFICATION"],
        [c for c in df.columns if isinstance(c, str) and c.strip().upper() == "BMS_ERROR"],
        [c for c in df.columns if isinstance(c, str) and c.strip().upper() == "OBC_CHARGE_POSSIBLE_STATUS"],
        [c for c in df.columns if isinstance(c, str) and c.strip().upper() == "EVCC_WARINING"],
        [c for c in df.columns if isinstance(c, str) and c.strip().upper() == "CONNECTER_LOCK_ERROR"]
    ]
    for col_list in fault_cols:
        if col_list:
            vals = [random.randint(0, 1) for _ in range(len(new_df))]
            for col in col_list:
                new_df[col] = vals
                
    # 充電器ステータスを 0 固定で埋める（例: CHARGER_STATUS_C1 等）
    charger_status_cols = [c for c in df.columns if isinstance(c, str) and "CHARGER_STATUS" in c.upper()]
    if charger_status_cols:
        zeros = [0] * len(new_df)
        for col in charger_status_cols:
            new_df[col] = zeros
    
    # EVCC制御状態
    evcc_control_cols = [c for c in df.columns if isinstance(c, str) and "EVCC_CNTRL_STATUS" in c.upper()]
    if evcc_control_cols:
        vals = [random.choice([0, 10, 21, 22, 23, 41, 42, 43, 50, 60]) for _ in range(len(new_df))]
        for col in evcc_control_cols:
            new_df[col] = vals
            
    # セル最大温度
    cell_max_temp_cols = [c for c in df.columns if isinstance(c, str) and "CELL_MAXIMUM_TEMP" in c.upper()]
    if cell_max_temp_cols:
        val = round(random.uniform(30.0, 35.0), 1)
        for col in cell_max_temp_cols:
            new_df[col] = [val] * len(new_df)

    # セル最小温度
    cell_min_temp_cols = [c for c in df.columns if isinstance(c, str) and "CELL_MINIMUM_TEMP" in c.upper()]
    if cell_min_temp_cols:
        val = round(random.uniform(25.0, 30.0), 1)
        for col in cell_min_temp_cols:
            new_df[col] = [val] * len(new_df)
            
    # VehicleNo
    vehicleno_cols = [c for c in df.columns if isinstance(c, str) and "VEHICLE_NO" in c.upper()]
    if vehicleno_cols:
        val = vehicleNo
        for col in vehicleno_cols:
            new_df[col] = [val] * len(new_df)

    # 日付文字列
    date_cols = [c for c in df.columns if isinstance(c, str) and "DATE" in c.upper()]
    if date_cols:
        val = date_str
        for col in date_cols:
            new_df[col] = [val] * len(new_df)

    # 既存の dtypes に合わせて可能ならキャスト
    for k, dtype in df.dtypes.items():
        try:
            new_df[k] = new_df[k].astype(dtype)
        except Exception:
            pass

    return pd.concat([df, new_df], ignore_index=True)

if __name__ == "__main__":
    main()