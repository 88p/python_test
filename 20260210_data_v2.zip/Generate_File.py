import json
import pandas as pd
import random
from pathlib import Path
from typing import Union
import math

#データ定義する
# バッテリー容量(kWh)
BATTERY_CAPACITY_KWH = 100.0
# 走行距離初期値(km)
INITIAL_DISTANCE_KM = 10.0
# SOC100%のときの走行可能距離(km)
MAX_DISTANCE_KM = 600.0

# 車両状態を表す構造体（クラス）を定義
class VehicleState:
    def __init__(self):
        self.vehicle_no = 0  # 車両番号
        self.soc_percent = 50.0  # 現在のSOC(%)
        self.distance_km = INITIAL_DISTANCE_KM  # 現在の走行距離(km)
        self.battery_capacity_kwh = BATTERY_CAPACITY_KWH * (self.soc_percent / 100.0)  # 現在のバッテリー容量(kWh)
        self.last_charge_date = None  # 最終充電日付
        self.total_ac_energy_kwh = 0.0 # 現在の総AC充電電力量(kWh)
        self.total_dc_energy_kwh = 0.0 # 現在の総DC充電電力量(kWh)
        self.total_charge_time = 0.0 # 現在の総充電時間(分)
        self.total_dc_charge_count = 0  # 現在の総DC充電回数
        self.total_ac_charge_count = 0  # 現在の総AC充電回数
        self.total_charge_count = 0  # 現在の総充電回数
        self.total_reason1_stop_count = 0  # 現在の要因1の充電停止総回数
        self.total_reason2_stop_count = 0  # 現在の要因2の充電停止総回数
        self.total_reason3_stop_count = 0  # 現在の要因3の充電停止総回数
        self.total_reason4_stop_count = 0  # 現在の要因4の充電停止総回数
        self.total_ac_charge_successed_count = 0  # 現在のAC充電成功総回数
        self.total_dc_charge_successed_count = 0  # 現在のDC充電成功総回数
        self.total_ac_charge_failed_count = 0  # 現在のAC充電失敗総回数
        self.total_dc_charge_failed_count = 0  # 現在のDC充電失敗総回数
        self.GPS_LATITUDE_DEGREES = 39  # 仮の緯度
        self.GPS_LONGITUDE_DEGREES = -76  # 仮の経度
        self.GPS_LATITUDE_MINUTES = 56  # 仮の緯度分
        self.GPS_LONGITUDE_MINUTES = 53  # 仮の経度分
        self.GPS_LATITUDE_SECONDS = 52  # 仮の緯度秒
        self.GPS_LONGITUDE_SECONDS = 2  # 仮の経度秒
        self.vehicle_speed_kmh = 0  # 現在の車速(km/h)
        self.p_range_status = 0.0  # Pレンジ状態
        self.HVB_aux_voltage = 0.0  # HVB補機電圧(V)
        self.DCrelay_fault_notification = 0  # DCリレー故障通知
        self.batteryPack_overTemp_notification = 0  # バッテリーパック過温度通知
        self.BMC_connecter_overTemp_notification = 0  # BMCコネクタ過熱通知
        self.CHARGER_STATUS = 0  # 充電器状態
        self.OBC_charge_possible_status = 0  # OBC充電可能状態
        self.EVCC_Control_status = 0  # EVCC制御状態
        self.EVCC_warning_request = 0  # EVCC警告要求
        self.ConnecterLock_error = 0  # コネクタロックエ異常
        self.cell_max_temp_c = 25.0  # セル最大温度(℃)
        self.cell_min_temp_c = 20.0  # セル最小温度(℃)

# 外気温度の定義（月ごと・地域ごとに範囲を変更可能なクラス管理）
class OutsideTemperatureManager:
    def __init__(self):
        # 月ごとの外気温範囲（後から変更可能）
        self.temp_ranges = {
            1: (-5.0, 7.0),
            2: (-3.0, 9.0),
            3: (0.0, 14.0),
            4: (5.0, 18.0),
            5: (10.0, 24.0),
            6: (15.0, 28.0),
            7: (20.0, 35.0),
            8: (20.0, 34.0),
            9: (15.0, 28.0),
            10: (8.0, 20.0),
            11: (2.0, 14.0),
            12: (-2.0, 8.0),
        }
        # 地域ごとの補正値（後から追加可能）
        self.region_offsets = {
            "default": 0.0,
            # "california": +5.0,
            # "florida": +3.0,
        }

    def get_temperature(self, month: int, region: str = "default") -> float:
        temp_min, temp_max = self.temp_ranges.get(month, (-10.0, 35.0))
        offset = self.region_offsets.get(region, 0.0)
        return random.uniform(temp_min, temp_max) + offset


def main():
    df = make_df_from_schema("labels.json")    
    df = make_records(df)
    # Export to CSV
    make_csv(df)
    
def make_records(df: pd.DataFrame) -> pd.DataFrame:
    
    if df is None:
        print("DataFrame is None, returning None.")
        return df

    # 外気温インスタンス生成
    outside_temp_manager = OutsideTemperatureManager()

    #全車両台数のループ
    for i in range(1):
        
        # 車両状態インスタンスを作成
        vehicle_state = VehicleState()
        # 車両番号を設定
        vehicle_state.vehicle_no = i
                
        # 初回充電日付を秒単位まで指定
        random_days = random.randint(1, 365)
        random_seconds = random.randint(0, 86399)  # 0～23:59:59
        vehicle_state.last_charge_date = pd.Timestamp.now() + pd.Timedelta(days=random_days, seconds=random_seconds)
        
        # 1車両分のRecord回数分ループ
        for j in range(3): #random.randint(5, 10)):
            
            # 1レコード分のデータを格納する辞書を初期化
            row = {}
            
            # ランダムなMACアドレスを生成してStringDtypeで格納
            mac = ":".join(f"{random.randint(0,255):02X}" for _ in range(6))
            
            # ReadyOnの回数を決定(1～4回)
            ready_on_count = random.randint(1, 4)
            
            # AC充電かDC充電かをランダムに決定
            is_ac_charge = random.choice([True, False])
            
            # 初回充電日付からの日付オフセットを加算
            random_days_offset = random.randint(1, 10)
            #充電日は前回の充電日からオフセットを加算
            vehicle_state.last_charge_date = vehicle_state.last_charge_date + pd.Timedelta(days=random_days_offset) #ここでは充電日付だけを変更
            date_str = vehicle_state.last_charge_date.strftime("%Y-%m-%d %H:%M:%S")
            
            # ReadyOn回数分ループ
            for k in range(ready_on_count):
                
                #EVSEMACアドレス
                row[f"EVSE_MACADDRESS_{k+1}"] = mac
                
                # 充電成功可否をランダムに決定（90%の確率で成功）
                charge_success = random.choices([True, False], weights=[90, 10])[0]
            
                # 成功か失敗かで分岐
                if charge_success: # 充電成功の場合
                    if is_ac_charge: # AC充電の場合
                        vehicle_state.total_ac_charge_successed_count += 1
                        # 今回のAC充電成功フラグ
                        row[f"AC_CHARGE_SUCESSED_FLAG_C{k+1}"] = k+1
                    else:
                        vehicle_state.total_dc_charge_successed_count += 1
                        # 今回のDC充電成功フラグ
                        row[f"DC_CHARGE_SUCESSED_FLAG_C{k+1}"] = k+1
                else: # 充電失敗の場合
                    if is_ac_charge: # AC充電の場合
                        vehicle_state.total_ac_charge_failed_count += 1
                        # 今回のAC充電失敗フラグ
                        row[f"AC_CHARGE_FAILED_FLAG_C{k+1}"] = k+1
                    else: # DC充電の場合
                        vehicle_state.total_dc_charge_failed_count += 1
                        # 今回のDC充電失敗フラグ
                        row[f"DC_CHARGE_FAILED_FLAG_C{k+1}"] = k+1
                    # "StopCharging","EVSE_UtilityInterruptEvent","EVSE_MAlfunction"のいずれかで充電停止したと仮定
                    row.update(generate_error_isolation(k+1))

                # 初回充電日付からの時刻オフセットを加算
                random_seconds_offset = random.randint(0, 86399)  # 0～23:59:59
                vehicle_state.last_charge_date = vehicle_state.last_charge_date + pd.Timedelta(seconds=random_seconds_offset) #ここでは充電時刻だけを変更
                date_str = vehicle_state.last_charge_date.strftime("%Y-%m-%d %H:%M:%S")
                
                if is_ac_charge:
                    # AC充電の場合
                    
                    # EVSEの充電出力(kW)
                    evse_power_kw = random.choice([3.0, 6.0, 9.0, 12.0])
                    # 充電時間の決定          
                    charge_time = random.randint(60, 960)  # 60分から960分
                    #走行距離の決定
                    #充電量の算出
                    delta_soc_Percent = ( evse_power_kw * ( charge_time / 60 ) ) / BATTERY_CAPACITY_KWH
                    if delta_soc_Percent > 1.0:
                        delta_soc_Percent = 1.0
                    #走行した距離
                    distance_km = delta_soc_Percent * MAX_DISTANCE_KM * 0.9  # 90%の効率を考慮
                    #充電終了SOC(%)
                    end_soc_percent = random.uniform(80.0, 100.0)
                    #充電開始SOC(%)
                    start_soc_percent = end_soc_percent - delta_soc_Percent * 100
                    if start_soc_percent < 0.0:
                        start_soc_percent = 0.0
                    # AC充電回数の更新
                    vehicle_state.total_ac_charge_count += 1
                    # 総充電時間の更新
                    vehicle_state.total_charge_time += charge_time
                    # 総AC充電電力量の更新
                    vehicle_state.total_ac_energy_kwh += round(delta_soc_Percent * BATTERY_CAPACITY_KWH, 2)
                    # 今回の充電時間
                    row[f"CHARGING_TIME_C{k+1}"] = charge_time
                    # 今回の充電電力量
                    row[f"CHARGING_POWER_C{k+1}"] = round(delta_soc_Percent * BATTERY_CAPACITY_KWH, 2)
                    # タイマー充電か今すぐ充電かをランダムに決定（2割がタイマー充電）
                    is_timer_charge = random.choices([True, False], weights=[2, 8])[0]
                    if is_timer_charge:
                        row[f"CHARGE_MODE_TIMER_FLAG_C{k+1}"] = 1  # タイマー充電ラベル
                    else:
                        row[f"CHARGE_MODE_NORMAL_FLAG_C{k+1}"] = 1  # 今すぐ充電ラベル
                    
                else:
                    # DC充電の場合
                    # EVSEの充電出力(kW)
                    evse_power_kw = random.choice([20.0, 60.0, 90.0, 120.0, 150.0, 180.0])
                    # 充電時間の決定
                    charge_time = random.randint(30, 50)  # 5分から30分
                    #走行距離の決定
                    #充電量の算出
                    delta_soc_Percent = ( evse_power_kw * ( charge_time / 60 ) ) / BATTERY_CAPACITY_KWH
                    if delta_soc_Percent > 1.0:
                        delta_soc_Percent = 1.0
                    #走行した距離
                    distance_km = delta_soc_Percent * MAX_DISTANCE_KM * 0.8  # DC充電は効率がやや低いと仮定
                    #充電終了SOC(%)
                    end_soc_percent = random.uniform(40.0, 80.0)
                    #充電開始SOC(%)
                    start_soc_percent = end_soc_percent - delta_soc_Percent * 100
                    if start_soc_percent < 0.0:
                        start_soc_percent = 0.0
                    # DC充電回数の更新
                    vehicle_state.total_dc_charge_count += 1
                    # 総充電時間の更新
                    vehicle_state.total_charge_time += charge_time
                    # 総DC充電電力量の更新
                    vehicle_state.total_dc_energy_kwh += round(delta_soc_Percent * BATTERY_CAPACITY_KWH, 2)
                    # 今回の充電時間
                    row[f"CHARGING_TIME_C{k+1}"] = charge_time
                    # 今回の充電電力量
                    row[f"CHARGING_POWER_C{k+1}"] = round(delta_soc_Percent * BATTERY_CAPACITY_KWH, 2)

                # 総充電回数の更新
                vehicle_state.total_charge_count += 1
                row[f"AllConnectionDetection_{k+1}"] = vehicle_state.total_charge_count
                
                # 外気温度の決定
                # 地域指定（今は"default"、後で変更可能）
                region = "default"
                month = vehicle_state.last_charge_date.month
                outside_temp_c = outside_temp_manager.get_temperature(month, region)
                
                # インレット端子温度の決定
                #generate_inlet_temp_c(outside_temp_c, charge_time, k+1)
                row.update(generate_inlet_temp_c(outside_temp_c, charge_time, k+1))
                
                # CPLT_Duty_Cycleの決定
                row.update(generate_CPLT_Duty_Cycle(charge_time, k+1))
                
                # PISW_Voltageの決定
                row.update(generate_PISW_Voltage(charge_time, k+1))
                
                # CHARGER_MAX_POWERの決定
                row.update(generate_CHARGER_MAX_POWER(evse_power_kw, k+1))
                
                # CHARGER_INPUT_VOLTAGEの決定
                row.update(generate_CHARGER_INPUT_VOLTAGE(charge_time, k+1))
                
                # CHARGER_OUTPUT_VOLTAGEの決定
                row.update(generate_CHARGER_OUTPUT_VOLTAGE(charge_time, k+1))
                
                # CHARGER_OUTPUT_POWERの決定
                row.update(generate_CHARGER_OUTPUT_POWER(charge_time, k+1))
                
                # DC_RELAY_TEMPの決定
                row.update(generate_DC_RELAY_TEMP(charge_time, k+1))
                
                # AC_RELAY_TEMPの決定
                row.update(generate_AC_RELAY_TEMP(charge_time, k+1))
                
                # 充電中時系列データの決定
                row.update(generate_inCharge_soc(charge_time, k+1,start_soc_percent, delta_soc_Percent*100))
                
                # 充電中電流時系列データの決定
                row.update(generate_inCharge_current(charge_time, k+1, evse_power_kw, start_soc_percent, delta_soc_Percent*100))
                
                # 充電中Win時系列データの決定
                row.update(generate_incharge_win(charge_time, k+1))
                
                # 充電中セル温度時系列データの決定
                row.update(generate_incharge_celltemp(charge_time, k+1, outside_temp_c))
                
                #print(f"VehicleNo: {i+1}, RecordNo: {j+1}, ChargeCount: {k+1}, Date: {date_str}, AC Charge?: {is_ac_charge}, Charge Time: {charge_time} min, deltaSOC: {delta_soc_Percent:.2f}, Start SOC: {start_soc_percent:.2f}%, End SOC: {end_soc_percent:.2f}%, Distance: {distance_km:.2f} km")

                

                if not is_ac_charge:
                    # DC充電の場合、ほぼ２回目の充電はしないはずなのでループを抜ける
                    break
                
            # rowに格納されたデータをDataFrameに追加
            row.update({
                "VEHICLE_NO": i + 1,
                "DATE": date_str,
                "AC_CHARGE_POWER_AMOUNT": vehicle_state.total_ac_energy_kwh,
                "DC_CHARGE_POWER_AMOUNT": vehicle_state.total_dc_energy_kwh,
                "CHARGE_TIME_AMOUNT": vehicle_state.total_charge_time,
                "DC_CHARGE_COUNTS": vehicle_state.total_dc_charge_count,
                "AC_CHARGE_COUNTS": vehicle_state.total_ac_charge_count,
                "AC_CHARGE_SUCESSED_COUNT": vehicle_state.total_ac_charge_successed_count,
                "DC_CHARGE_SUCESSED_COUNT": vehicle_state.total_dc_charge_successed_count,
                "AC_CHARGE_FAILED_COUNT": vehicle_state.total_ac_charge_failed_count,
                "DC_CHARGE_FAILED_COUNT": vehicle_state.total_dc_charge_failed_count
            })
            
            # CANの初期値データを生成
            row.update({
                "GPS_LATITUDE_DEGREES": vehicle_state.GPS_LATITUDE_DEGREES,
                "GPS_LONGITUDE_DEGREES": vehicle_state.GPS_LONGITUDE_DEGREES,
                "GPS_LATITUDE_MINUTES": vehicle_state.GPS_LATITUDE_MINUTES,
                "GPS_LONGITUDE_MINUTES": vehicle_state.GPS_LONGITUDE_MINUTES,
                "GPS_LATITUDE_SECONDS": vehicle_state.GPS_LATITUDE_SECONDS,
                "GPS_LONGITUDE_SECONDS": vehicle_state.GPS_LONGITUDE_SECONDS,
                "SOC": vehicle_state.soc_percent,
                "Mileage": vehicle_state.distance_km,
                "VEHICLE_SPEED": vehicle_state.vehicle_speed_kmh,
                "OUTSIDE_TEMP": round(outside_temp_c,2),
                "P_RANGE_STATUS": vehicle_state.p_range_status,
                "HVB_AUX_VOLTAGE": vehicle_state.HVB_aux_voltage,
                "DC_RELAY_FAIL_NOTIFICATION": vehicle_state.DCrelay_fault_notification,
                "BAT_PACK_TEMP_ERROR_NOTIFICATION": vehicle_state.batteryPack_overTemp_notification,
                "BMS_ERROR": vehicle_state.BMC_connecter_overTemp_notification,
                "CHARGER_STATUS": vehicle_state.CHARGER_STATUS,
                "OBC_CHARGE_POSSIBLE_STATUS": vehicle_state.OBC_charge_possible_status,
                "EVCC_CNTRL_STATUS": vehicle_state.EVCC_Control_status,
                "EVCC_WARINING": vehicle_state.EVCC_warning_request,
                "CONNECTER_LOCK_ERROR": vehicle_state.ConnecterLock_error,
                "CELL_MAXIMUM_TEMP": vehicle_state.cell_max_temp_c,
                "CELL_MINIMUM_TEMP": vehicle_state.cell_min_temp_c
            })
            df = pd.concat([df, pd.DataFrame([row])], ignore_index=True)
            
            # ここでCANデータ生成関数呼び出し
            addCANdf = make_df_record_CAN(charge_time, k+1, vehicle_state, outside_temp_c)
            #もう一回concatする
            
            # 既存の dtypes に合わせて可能ならキャスト
            for m, dtype in df.dtypes.items():
                try:
                    addCANdf[m] = addCANdf[m].astype(dtype)
                except Exception:
                    pass
            
            df = pd.concat([df, addCANdf], ignore_index=True, sort=False)
            print(f"VehicleDataCreated No.{i+1}")
    return df

            
def generate_inlet_temp_c(outside_temp_c: float, charge_time: int, charge_cnt: int) -> float:
    # インレット端子温度を外気温度に基づいて決定
    
    inlet_row = {}
    # プロット数 = ChargeTime * 60 / 10
    plots = max(0, int(charge_time * 60 / 10))

    # 正規分布の中心はインデックス 6 (Inlet_Terminal_Temp_C1_006)
    mean_idx = 6.0
    sd = 1.5  # 標準偏差（必要なら調整）

    # 1..10 の位置に対する重みを計算して正規分布に従う確率に正規化
    positions = list(range(1, 11))
    weights = [math.exp(-0.5 * ((p - mean_idx) / sd) ** 2) for p in positions]
    total = sum(weights)
    probs = [w / total for w in weights] if total > 0 else [1.0 / 10] * 10

    # plots 回選んで各位置の出現回数をカウント（Multinomial の代替）
    picks = random.choices(positions, weights=probs, k=plots)
    counts = {p: 0 for p in positions}
    for p in picks:
        counts[p] += 1

    # ChargeCnt に応じて Inlet_Terminal_Temp_C1_001..010 に対応する値を代入
    # ChargeCnt に応じて C1～C4 の各チャネルに同じ counts を割り当てる
    for i in positions:
        colname = f"Inlet_Terminal_Temp_C{charge_cnt}_{i:03d}"
        inlet_row[colname] = counts[i]
    return inlet_row

def generate_CPLT_Duty_Cycle(charge_time: int,charge_cnt: int) -> float:
    
    CPLTDuty_row = {}
    # プロット数 = ChargeTime * 60 / 10
    plots = max(0, int(charge_time * 60 / 10))
    # 一様分布で各位置に均等に分布させる
    positions = list(range(1, 16))
    counts = {p: 0 for p in positions}

    picks = random.choices(positions, k=plots)
    for p in picks:
        counts[p] += 1

    # ChargeCnt に応じて C1～C4 の各チャネルに同じ counts を割り当てる
    for i in positions:
        colname = f"CPLT_DUTY_C{charge_cnt}_{i:03d}"
        CPLTDuty_row[colname] = counts[i]
    return CPLTDuty_row

def generate_PISW_Voltage(charge_time: int,charge_cnt: int) -> float:
    PISW_row = {}
    # プロット数 = ChargeTime * 60 / 10
    plots = max(0, int(charge_time * 60 / 10))
    # 一様分布で各位置に均等に分布させる
    positions = list(range(1, 6))
    counts = {p: 0 for p in positions}

    picks = random.choices(positions, k=plots)
    for p in picks:
        counts[p] += 1

    # ChargeCnt に応じて C1～C4 の各チャネルに同じ counts を割り当てる
    for i in positions:
        colname = f"PISW_Voltage_C{charge_cnt}_{i:03d}"
        PISW_row[colname] = counts[i]
    return PISW_row

def generate_CHARGER_MAX_POWER(evse_power_kw: float, charge_cnt: int) -> float:
    CHARGERMaxPower_row = {}
    #ここは後で手直しが必要。
    #現在はランダムな値を入力しているが、実際には時系列の充電データに基づいて決定する必要がある。
    CHARGERMaxPower_row[f"CHARGER_MAX_POWER_C{charge_cnt}"] = round(evse_power_kw + random.uniform(-5, 5), 2)
    return CHARGERMaxPower_row

def generate_CHARGER_INPUT_VOLTAGE(charge_time: float, charge_cnt: int) -> float:
    charger_input_voltage_row = {}
    # プロット数 = ChargeTime * 60 / 10
    plots = max(0, int(charge_time * 60 / 10))

    positions = list(range(1, 10))
    counts = {p: 0 for p in positions}

    picks = random.choices(positions, k=plots)
    for p in picks:
        counts[p] += 1

    # ChargeCnt に応じて C1～C4 の各チャネルに同じ counts を割り当てる
    for i in positions:
        colname = f"CHARGER_INPUT_VOLTAGE_C{charge_cnt}_{i:03d}"
        charger_input_voltage_row[colname] = counts[i]
    return charger_input_voltage_row

def generate_CHARGER_OUTPUT_VOLTAGE(charge_time: float, charge_cnt: int) -> float:
    charger_output_voltage_row = {}
    # プロット数 = ChargeTime * 60 / 10
    plots = max(0, int(charge_time * 60 / 10))

    positions = list(range(1, 10))
    counts = {p: 0 for p in positions}

    picks = random.choices(positions, k=plots)
    for p in picks:
        counts[p] += 1

    # ChargeCnt に応じて C1～C4 の各チャネルに同じ counts を割り当てる
    for i in positions:
        colname = f"CHARGER_OUTPUT_VOLTAGE_C{charge_cnt}_{i:03d}"
        charger_output_voltage_row[colname] = counts[i]
    return charger_output_voltage_row

def generate_CHARGER_OUTPUT_POWER(charge_time: float, charge_cnt: int) -> float:
    charger_output_power_row = {}
    # プロット数 = ChargeTime * 60 / 10
    plots = max(0, int(charge_time * 60 / 10))

    positions = list(range(1, 10))
    counts = {p: 0 for p in positions}

    picks = random.choices(positions, k=plots)
    for p in picks:
        counts[p] += 1

    # ChargeCnt に応じて C1～C4 の各チャネルに同じ counts を割り当てる
    for i in positions:
        colname = f"CHARGER_OUTPUT_POWER_C{charge_cnt}_{i:03d}"
        charger_output_power_row[colname] = counts[i]
    return charger_output_power_row

def generate_DC_RELAY_TEMP(charge_time: float, charge_cnt: int) -> float:
    dc_relay_temp_row = {}
    # プロット数 = ChargeTime * 60 / 10
    plots = max(0, int(charge_time * 60 / 10))

    # 正規分布の中心はインデックス 6 (Inlet_Terminal_Temp_C1_006)
    mean_idx = 6.0
    sd = 1.5  # 標準偏差（必要なら調整）

    # 1..10 の位置に対する重みを計算して正規分布に従う確率に正規化
    positions = list(range(1, 9))
    weights = [math.exp(-0.5 * ((p - mean_idx) / sd) ** 2) for p in positions]
    total = sum(weights)
    probs = [w / total for w in weights] if total > 0 else [1.0 / 8] * 8

    # plots 回選んで各位置の出現回数をカウント（Multinomial の代替）
    picks = random.choices(positions, weights=probs, k=plots)
    counts = {p: 0 for p in positions}
    for p in picks:
        counts[p] += 1

    # ChargeCnt に応じて Inlet_Terminal_Temp_C1_001..010 に対応する値を代入
    # ChargeCnt に応じて C1～C4 の各チャネルに同じ counts を割り当てる
    for i in positions:
        colname = f"DC_RELAY_TEMP_C{charge_cnt}_{i:03d}"
        dc_relay_temp_row[colname] = counts[i]
    return dc_relay_temp_row

def generate_AC_RELAY_TEMP(charge_time: float, charge_cnt: int) -> float:
    ac_relay_temp_row = {}
    # プロット数 = ChargeTime * 60 / 10
    plots = max(0, int(charge_time * 60 / 10))

    positions = list(range(1, 9))
    counts = {p: 0 for p in positions}

    picks = random.choices(positions, k=plots)
    for p in picks:
        counts[p] += 1

    # ChargeCnt に応じて C1～C4 の各チャネルに同じ counts を割り当てる
    for i in positions:
        colname = f"AC_RELAY_TEMP_C{charge_cnt}_{i:03d}"
        ac_relay_temp_row[colname] = counts[i]
    return ac_relay_temp_row

#充電中時系列データの生成
def generate_inCharge_soc(charge_time: float, charge_cnt: int, start_soc_percent: float, delta_soc_percent: float) -> float:
    #充電中電流,Win,SOC,セル温度
    inCharge_row = {}
    # EVの充電中の入力電力、電流値、SOC、セル温度を時系列で生成するロジックをここに実装
    # 例として、charge_timeに基づいてランダムな値を生成
    # プロット数は charge_time (60秒ごとに1プロット)
    plots = max(0, int(charge_time))
    
    # SOC時系列データ生成
    soc_series = []
    # 1プロットごとのSOC増分
    soc_increment = delta_soc_percent / plots if plots > 0 else 0

    for i in range(plots):
        soc_value = start_soc_percent + soc_increment * i
        # 100%を超えないように制限
        soc_value = min(soc_value, 100.0)
        soc_series.append(round(soc_value, 2))

    # SOC時系列データを別変数に保存
    #inCharge_row[f"IN_CHARGE_SOC_C{charge_cnt}"] = soc_series
    #print(f"SOC Series for Charge Count {charge_cnt}: {soc_series}")
    
    # inCharge_rowを5plotsに間引く (暫定処理)
    downsampled_soc_series = []
    if plots <= 5:
        downsampled_soc_series = soc_series
    else:
        step = plots / 5
        for i in range(5):
            index = int(i * step)
            downsampled_soc_series.append(soc_series[index])
            inCharge_row[f"IN_CHARGE_SOC_C{charge_cnt}_{i+1:03d}"] = soc_series[index]
    #print(f"Downsampled SOC Series for Charge Count {charge_cnt}: {downsampled_soc_series}")
    
    return inCharge_row

def generate_inCharge_current(charge_time: float, charge_cnt: int, evse_power_kw: float, start_soc_percent: float, delta_soc_percent: float) -> float:
    inCharge_row = {}
    # EVの充電中の電流値を時系列で生成するロジックをここに実装
    # charge_timeに基づいてランダムな値を生成
    # プロット数は charge_time (60秒ごとに1プロット)
    plots = max(0, int(charge_time))
    # evse_power_kw / 充電電圧(V) から充電電流(A)を計算 (仮に400Vとする)
    
    #plots数に基づいて山を描くように電流値を生成
    # ここでは単純にランダムな値を生成する例を示す
    # 実際には充電プロファイルに基づいて生成する必要がある
    # 例: 電流値は0からevse_power_kw の範囲でランダムに生成
    # 弧を描くように電流値を生成（sinカーブを利用）
    current_series = []
    for i in range(plots):
        # 0～πまで均等に分割してsinカーブを使う
        angle = math.pi * i / (plots - 1) if plots > 1 else 0
        current_value = evse_power_kw * math.sin(angle)
        current_value = max(0.0, round(current_value, 2))
        current_series.append(current_value)
    
    # Current時系列データ生成
    current_series = []
    for i in range(plots):
        current_value = random.uniform(0.0, 100.0)  # 仮の範囲
        current_series.append(round(current_value, 2))

    # 電流時系列データを別変数に保存
    #inCharge_row[f"IN_CHARGE_CURRENT_C{charge_cnt}"] = current_series
    
    #　5plotsに間引く (暫定処理)
    downsampled_current_series = []
    if plots <= 5:
        downsampled_current_series = current_series
    else:
        step = plots / 5
        for i in range(5):
            index = int(i * step)
            downsampled_current_series.append(current_series[index])
            inCharge_row[f"IN_CHARGE_CURRENT_C{charge_cnt}_{i+1:03d}"] = current_series[index]
    
    return inCharge_row

def generate_incharge_win(charge_time: float, charge_cnt: int) -> float:
    inCharge_row = {}
    # EVの充電中のWin値を時系列で生成するロジックをここに実装
    # charge_timeに基づいてランダムな値を生成
    # プロット数は charge_time (60秒ごとに1プロット)
    plots = max(0, int(charge_time))
    
    win_series = []
    for i in range(plots):
        win_value = random.uniform(0.0, 100.0)  # 仮の範囲
        win_series.append(round(win_value, 2))

    # Win時系列データを別変数に保存
    #inCharge_row[f"IN_CHARGE_WIN_C{charge_cnt}"] = win_series
    
    # 5plotsに間引く (暫定処理)
    downsampled_win_series = []
    if plots <= 5:
        downsampled_win_series = win_series
    else:
        step = plots / 5
        for i in range(5):
            index = int(i * step)
            downsampled_win_series.append(win_series[index])
            inCharge_row[f"IN_CHARGE_WIN_C{charge_cnt}_{i+1:03d}"] = win_series[index]
    
    return inCharge_row

def generate_incharge_celltemp(charge_time: float, charge_cnt: int, outside_temp_c: float) -> float:
    inCharge_row = {}
    # EVの充電中のセル温度値を時系列で生成するロジックをここに実装
    # charge_timeに基づいてランダムな値を生成
    # プロット数は charge_time (60秒ごとに1プロット)
    plots = max(0, int(charge_time))
    
    celltemp_series = []
    for i in range(plots):
        #開始温度から終了温度まで徐々に上昇するイメージで生成
        #開始温度は外気温度から±5度、終了温度は40度程度と仮定
        start_temp = outside_temp_c + random.uniform(-5.0, 5.0)
        end_temp = 40.0 + random.uniform(-5.0, 5.0)
        celltemp_value = start_temp + (end_temp - start_temp) * i / (plots - 1) if plots > 1 else start_temp
        celltemp_series.append(round(celltemp_value, 2))

    # セル温度時系列データを別変数に保存
    #inCharge_row[f"IN_CHARGE_CELLTEMP_C{charge_cnt}"] = celltemp_series
    
    # 5plotsに間引く (暫定処理)
    downsampled_celltemp_series = []
    if plots <= 5:
        downsampled_celltemp_series = celltemp_series
    else:
        step = plots / 5
        for i in range(5):
            index = int(i * step)
            downsampled_celltemp_series.append(celltemp_series[index])
            inCharge_row[f"IN_CHARGE_CELL_MAX_TEMP_C{charge_cnt}_{i+1:03d}"] = celltemp_series[index]
            
    #数値を-5~-10した値のの列も生成
    for i in range(5):
        colname = f"IN_CHARGE_CELL_MIN_TEMP_C{charge_cnt}_{i+1:03d}"
        inCharge_row[colname] = round(inCharge_row[f"IN_CHARGE_CELL_MAX_TEMP_C{charge_cnt}_{i+1:03d}"] - random.uniform(5.0, 10.0), 2)
 
    return inCharge_row

def generate_error_isolation(charge_cnt: int) -> dict:
    # エラー絶縁判定をランダムに生成（0または1）
    error_row = {
        "EVSE_MAlfuction_C"+str(charge_cnt), \
        "EVSE_Shutdown_C"+str(charge_cnt), \
        "EVSE_UtilityInterruptEvent_C"+str(charge_cnt), \
        "FAILED_C"+str(charge_cnt)+"_001", \
        "FAILED_C"+str(charge_cnt)+"_002", \
        "FAILED_C"+str(charge_cnt)+"_003", \
        "FAILED_C"+str(charge_cnt)+"_004", \
        "FAILED_C"+str(charge_cnt)+"_005", \
        "FAILED_C"+str(charge_cnt)+"_006", \
        "FAILED_C"+str(charge_cnt)+"_007", \
        "FAILED_C"+str(charge_cnt)+"_008", \
        "FAILED_C"+str(charge_cnt)+"_009", \
        "FAILED_C"+str(charge_cnt)+"_010", \
            
        "FAILED_C"+str(charge_cnt)+"_011", \
        "FAILED_C"+str(charge_cnt)+"_012", \
        "FAILED_C"+str(charge_cnt)+"_013", \
        "FAILED_C"+str(charge_cnt)+"_014", \
        "FAILED_C"+str(charge_cnt)+"_015", \
        "FAILED_C"+str(charge_cnt)+"_016", \
        "FAILED_C"+str(charge_cnt)+"_017", \
        "FAILED_C"+str(charge_cnt)+"_018", \
        "FAILED_C"+str(charge_cnt)+"_019", \
        "FAILED_C"+str(charge_cnt)+"_020", \

        "FAILED_C"+str(charge_cnt)+"_021", \
        "FAILED_C"+str(charge_cnt)+"_022", \
        "FAILED_C"+str(charge_cnt)+"_023", \
        "FAILED_C"+str(charge_cnt)+"_024", \
        "FAILED_C"+str(charge_cnt)+"_025", \
        "FAILED_C"+str(charge_cnt)+"_026", \
        "FAILED_C"+str(charge_cnt)+"_027", \
        "FAILED_C"+str(charge_cnt)+"_028", \
        "FAILED_C"+str(charge_cnt)+"_029", \
        "FAILED_C"+str(charge_cnt)+"_030", \

        "FAILED_C"+str(charge_cnt)+"_031", \
        "FAILED_C"+str(charge_cnt)+"_032", \
        "FAILED_C"+str(charge_cnt)+"_033", \
        "FAILED_C"+str(charge_cnt)+"_034", \
    }
    # error_row を辞書に変換し、すべて None で初期化
    error_row = {col: None for col in error_row}
    # ランダムに1つ選んで値を1にする
    selected_col = random.choice(list(error_row.keys()))
    error_row[selected_col] = 1
    return error_row

def make_df_record_CAN(charge_time: float, charge_cnt: int, vehicle_state, outside_temp) -> pd.DataFrame:
    
    df = pd.DataFrame()
    # レコード数: ChargeTime　60秒ごとに1レコード
    n_records = max(1, int(charge_time * 1))
    row = {}
    # 時系列ラベルの初期値と終了値を決定
    start_soc = vehicle_state.soc_percent
    end_soc = random.uniform(10.0, start_soc)
    start_mileage = vehicle_state.distance_km
    end_mileage = start_mileage + (end_soc - start_soc / 100.0 * MAX_DISTANCE_KM * 0.9)
    # GPS情報の取得
    start_GPS_lat_deg = vehicle_state.GPS_LATITUDE_DEGREES
    start_GPS_lon_deg = vehicle_state.GPS_LONGITUDE_DEGREES
    start_GPS_lat_min = vehicle_state.GPS_LATITUDE_MINUTES
    start_GPS_lon_min = vehicle_state.GPS_LONGITUDE_MINUTES
    start_GPS_lat_sec = vehicle_state.GPS_LATITUDE_SECONDS
    start_GPS_lon_sec = vehicle_state.GPS_LONGITUDE_SECONDS
    # start_mileage から end_mileage までの距離（km）を西方向に移動した位置のGPS情報を計算
    delta_km = end_mileage - start_mileage
    # 全方位に移動（ランダムな方位角）
    bearing_deg = random.uniform(0, 360)
    bearing_rad = math.radians(bearing_deg)
    # 地球半径（km）
    earth_radius_km = 6371.0
    # 現在位置を十進法に変換
    start_lat = start_GPS_lat_deg + start_GPS_lat_min / 60.0 + start_GPS_lat_sec / 3600.0
    start_lon = start_GPS_lon_deg + start_GPS_lon_min / 60.0 + start_GPS_lon_sec / 3600.0
    # 移動距離を地球上で計算
    ang_dist = delta_km / earth_radius_km
    lat1 = math.radians(start_lat)
    lon1 = math.radians(start_lon)
    lat2 = math.asin(math.sin(lat1) * math.cos(ang_dist) +
                     math.cos(lat1) * math.sin(ang_dist) * math.cos(bearing_rad))
    lon2 = lon1 + math.atan2(math.sin(bearing_rad) * math.sin(ang_dist) * math.cos(lat1),
                             math.cos(ang_dist) - math.sin(lat1) * math.sin(lat2))
    end_lat = math.degrees(lat2)
    end_lon = math.degrees(lon2)
    # 陸地判定（簡易: 米国本土範囲内に制限）
    # 米国本土: 緯度 24～49, 経度 -125～-66
    if not (24 <= end_lat <= 49 and -125 <= end_lon <= -66):
        # 範囲外なら米国本土中心(37.5, -96.5)にする
        end_lat = 37.5 + random.uniform(-5, 5)
        end_lon = -96.5 + random.uniform(-10, 10)
    # DMS変換
    def _dec_to_dms(value):
        sign = -1 if value < 0 else 1
        a = abs(value)
        deg = int(math.floor(a))
        minutes = int(math.floor((a - deg) * 60.0))
        seconds = round((a - deg - minutes / 60.0) * 3600.0, 3)
        return int(deg * sign), minutes, seconds
    end_GPS_lat_deg, end_GPS_lat_min, end_GPS_lat_sec = _dec_to_dms(end_lat)
    end_GPS_lon_deg, end_GPS_lon_min, end_GPS_lon_sec = _dec_to_dms(end_lon)
    
    start_outside_temp = outside_temp
    end_outside_temp = start_outside_temp + random.uniform(-3.0, 3.0)
    start_cell_max_temp = vehicle_state.cell_max_temp_c
    end_cell_max_temp = start_cell_max_temp + random.uniform(15.0, 30.0)
    start_cell_min_temp = vehicle_state.cell_min_temp_c
    end_cell_min_temp = start_cell_min_temp + random.uniform(1.0, 10.0)
    
    #　時系列データを生成
    for i in range(n_records):
        # CANデータの各フィールドを生成

        # 値を線形補間で計算（n_recordsが1の場合はstart_socをそのまま使用）
        if n_records == 1:
            row[f"SOC"] = round(start_soc, 2)
            row[f"Mileage"] = round(start_mileage, 2)
            row[f"GPS_LATITUDE_DEGREES"] = start_GPS_lat_deg
            row[f"GPS_LONGITUDE_DEGREES"] = start_GPS_lon_deg
            row[f"GPS_LATITUDE_MINUTES"] = start_GPS_lat_min
            row[f"GPS_LONGITUDE_MINUTES"] = start_GPS_lon_min
            row[f"GPS_LATITUDE_SECONDS"] = start_GPS_lat_sec
            row[f"GPS_LONGITUDE_SECONDS"] = start_GPS_lon_sec
            row[f"OUTSIDE_TEMP"] = round(start_outside_temp, 2)
            row[f"CELL_MAX_TEMP"] = round(start_cell_max_temp, 2)
            row[f"CELL_MIN_TEMP"] = round(start_cell_min_temp, 2)
        else:
            row[f"SOC"] = round(start_soc + (end_soc - start_soc) * i / (n_records - 1), 2)
            row[f"Mileage"] = round(start_mileage + (end_mileage - start_mileage) * i / (n_records - 1), 2)
            row[f"GPS_LATITUDE_DEGREES"] = round(start_GPS_lat_deg + (end_GPS_lat_deg - start_GPS_lat_deg) * i / (n_records - 1))
            row[f"GPS_LONGITUDE_DEGREES"] = round(start_GPS_lon_deg + (end_GPS_lon_deg - start_GPS_lon_deg) * i / (n_records - 1))
            row[f"GPS_LATITUDE_MINUTES"] = round(start_GPS_lat_min + (end_GPS_lat_min - start_GPS_lat_min) * i / (n_records - 1))
            row[f"GPS_LONGITUDE_MINUTES"] = round(start_GPS_lon_min + (end_GPS_lon_min - start_GPS_lon_min) * i / (n_records - 1))
            row[f"GPS_LATITUDE_SECONDS"] = round(start_GPS_lat_sec + (end_GPS_lat_sec - start_GPS_lat_sec) * i / (n_records - 1), 3)
            row[f"GPS_LONGITUDE_SECONDS"] = round(start_GPS_lon_sec + (end_GPS_lon_sec - start_GPS_lon_sec) * i / (n_records - 1), 3)
            row[f"OUTSIDE_TEMP"] = round(start_outside_temp + (end_outside_temp - start_outside_temp) * i / (n_records - 1), 2)
            row[f"CELL_MAXIMUM_TEMP"] = round(start_cell_max_temp + (end_cell_max_temp - start_cell_max_temp) * i / (n_records - 1), 2)
            row[f"CELL_MINIMUM_TEMP"] = round(start_cell_min_temp + (end_cell_min_temp - start_cell_min_temp) * i / (n_records - 1), 2)
        
        row[f"DATE"] = str((vehicle_state.last_charge_date + pd.Timedelta(minutes=i+1)).strftime("%Y-%m-%d %H:%M:%S"))
        row[f"VEHICLE_NO"] = vehicle_state.vehicle_no+1
        row[f"P_RANGE_STATUS"] = 1  # 0:Pレンジ 1:Pレンジ以外　(常に走行中の想定)
        row[f"VEHICLE_SPEED"] = round(random.uniform(10.0, 120.0), 1)  # km/h
        row[f"HVB_AUX_VOLTAGE"] = random.choices([0, 1], weights=[98, 2])[0]
        row[f"DC_RELAY_FAIL_NOTIFICATION"] = random.choices([0, 1], weights=[98, 2])[0]
        row[f"BAT_PACK_TEMP_ERROR_NOTIFICATION"] = random.choices([0, 1], weights=[98, 2])[0]
        row[f"BMS_ERROR"] = random.choices([0, 1], weights=[98, 2])[0]
        row[f"CHARGER_STATUS"] = random.choices([0, 1, 2, 3], weights=[70, 10, 10, 10])[0] #値確認
        row[f"OBC_CHARGE_POSSIBLE_STATUS"] = random.choices([0, 1], weights=[100, 0])[0]
        row[f"EVCC_CNTRL_STATUS"] = random.choices([0, 1, 2, 3], weights=[100, 0, 0, 0])[0] #値確認
        row[f"EVCC_WARINING"] = random.choices([0, 1], weights=[98, 2])[0]
        row[f"CONNECTER_LOCK_ERROR"] = random.choices([0, 1], weights=[98, 2])[0]
        
        # i行目のデータができたら、rowをdfに追加していく
        #df = pd.concat([df, pd.DataFrame([row])], ignore_index=True)
        # appendの方がconcatより高速（ただしDataFrameのリストでまとめてconcatするのが最速）
        # ここではループ外でまとめてconcatする方式に変更
        if 'rows_list' not in locals():
            rows_list = []
        #rows_list.append(row)
        rows_list.append(row.copy())

    #return df
    #Dataframeを返す前に車両状態を更新する
    #vehicle_state.soc_percent = row["SOC"]
    #vehicle_state.distance_km = row["Mileage"]
    #vehicle_state.GPS_LATITUDE_DEGREES = row["GPS_LATITUDE_DEGREES"]
    #vehicle_state.GPS_LONGITUDE_DEGREES = row["GPS_LONGITUDE_DEGREES"]
    #vehicle_state.GPS_LATITUDE_MINUTES = row["GPS_LATITUDE_MINUTES"]
    #vehicle_state.GPS_LONGITUDE_MINUTES = row["GPS_LONGITUDE_MINUTES"]
    #vehicle_state.GPS_LATITUDE_SECONDS = row["GPS_LATITUDE_SECONDS"]
    #vehicle_state.GPS_LONGITUDE_SECONDS = row["GPS_LONGITUDE_SECONDS"]
    return pd.DataFrame(rows_list)

def make_csv(df: pd.DataFrame) -> None:
    
    out_path = Path("labels_export_1000Vehicle_v2.csv")
    if df is None or df.empty:
        print("DataFrame is empty, skipping CSV export.")
    else:
        df.to_csv(out_path, index=False, encoding="utf-8-sig")
        print(f"Exported DataFrame to: {out_path.resolve()}")



# schema.json から DataFrame を作成
def make_df_from_schema(json_path: Union[str, Path]) -> pd.DataFrame:
    data = json.loads(Path(json_path).read_text(encoding="utf-8"))
    cols = data["columns"]

    if not cols:
        return pd.DataFrame()

    # 文字列リスト形式にも対応
    if isinstance(cols[0], str):
        return pd.DataFrame(columns=cols)

    names = [c["name"] for c in cols]
    dtypes = {c["name"]: c["dtype"] for c in cols if "dtype" in c}

    df = pd.DataFrame(columns=names)

    # データ型を設定
    for k, v in dtypes.items():
        if v.startswith("datetime"):
            continue
        df[k] = df[k].astype(v)

    return df



if __name__ == "__main__":
    main()